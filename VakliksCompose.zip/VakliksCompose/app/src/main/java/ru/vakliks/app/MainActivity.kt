package ru.vakliks.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import ru.vakliks.app.navigation.NavGraph
import ru.vakliks.app.ui.theme.VakliksTheme
import ru.vakliks.app.ui.theme.ThemePreference
import androidx.compose.runtime.SideEffect
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.luminance

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        ThemePreference.initialize(this)
        setContent {
            VakliksTheme {
                val lightBackground = MaterialTheme.colorScheme.background.luminance() > 0.5f
                SideEffect {
                    WindowCompat.getInsetsController(window, window.decorView)
                        .isAppearanceLightStatusBars = lightBackground
                    WindowCompat.getInsetsController(window, window.decorView)
                        .isAppearanceLightNavigationBars = lightBackground
                }
                NavGraph()
            }
        }
    }
}
