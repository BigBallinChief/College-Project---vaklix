package ru.vakliks.app.data

/** Presentation model populated from Supabase rather than hard-coded vacancies. */
data class Vacancy(
    val id: String,
    val title: String,
    val salary: String,
    val company: String,
    val city: String = "",
    val rating: String = "—",
    val reviews: String = "0 отзывов",
    val summary: String = "",
    val organizationId: String = "",
    val images: List<String> = emptyList(),
    val workSchedule: String = "",
    val experience: String = "",
    val workFormat: String = "",
    val employmentType: String = "",
    val salaryFrom: Long? = null,
    val salaryTo: Long? = null,
    val salaryPeriod: String = "month",
    val hoursPerDay: Int? = null,
    val nightShifts: Boolean = false,
    val paymentFrequency: String = "",
    val specialization: String = "",
    val status: String = "published",
    val publishedAt: String = ""
)
