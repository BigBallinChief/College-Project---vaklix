package ru.vakliks.app.data

data class VacancyFilters(
    val query:String="",val city:String="",val schedule:String="",val experience:String="",
    val workFormat:String="",val employment:String="",val minSalary:Long?=null,
    val specialization:String="",val period:String=""
) {
    fun matches(v:Vacancy):Boolean =
        (query.isBlank() || listOf(v.title,v.company,v.city,v.summary).any{it.contains(query,true)}) &&
        (city.isBlank() || v.city.contains(city,true)) &&
        (schedule.isBlank() || v.workSchedule == schedule) &&
        (experience.isBlank() || v.experience == experience) &&
        (workFormat.isBlank() || v.workFormat == workFormat) &&
        (employment.isBlank() || v.employmentType == employment) &&
        (minSalary == null || ((v.salaryTo ?: v.salaryFrom) ?: -1)>=minSalary) &&
        (specialization.isBlank() || v.specialization.contains(specialization,true)) &&
        (period.isBlank() || v.salaryPeriod == period)
}
