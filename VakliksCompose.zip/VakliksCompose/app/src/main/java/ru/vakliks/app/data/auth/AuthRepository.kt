package ru.vakliks.app.data.auth

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import ru.vakliks.app.BuildConfig
import java.net.HttpURLConnection
import java.net.URL
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.KeyStore

/** Supabase Auth HTTP API. Only the public publishable key ships with the app. */
class AuthRepository(context: Context) {
    private val sessionStore = EncryptedSessionStore(context.applicationContext)
    private val baseUrl = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val publicKey = BuildConfig.SUPABASE_PUBLISHABLE_KEY

    companion object {
        // Shared between AuthRepository instances created by different Compose screens.
        private val refreshMutex = Mutex()
    }

    private fun tokenValid(token: String?): Boolean {
        if (token.isNullOrBlank()) return false
        return try {
            val json = String(Base64.decode(token.split('.')[1], Base64.URL_SAFE or Base64.NO_WRAP))
            val expiresAt = JSONObject(json).optLong("exp")
            expiresAt > System.currentTimeMillis() / 1000 + 90
        } catch (_: Exception) { false }
    }

    data class SignUpResult(val needsEmailConfirmation: Boolean)

    fun currentEmail(): String? = sessionStore.readEmail()

    /** Use cached JWT and refresh only when near expiry, serialized across screens. */
    suspend fun databaseToken(): String? {
        val current = sessionStore.readAccessToken()
        if (tokenValid(current)) return current
        return if (restoreSession()) sessionStore.readAccessToken() else null
    }

    suspend fun signUp(email: String, password: String, fullName: String): SignUpResult {
        val payload = JSONObject().put("email", email).put("password", password)
            .put("data", JSONObject().put("full_name", fullName.trim()))
        val response = request("/auth/v1/signup", payload)
        val session = response.optString("access_token")
        if (session.isNotBlank()) saveSession(response)
        return SignUpResult(needsEmailConfirmation = session.isBlank())
    }

    suspend fun signIn(email: String, password: String) {
        val response = request("/auth/v1/token?grant_type=password", JSONObject().put("email", email).put("password", password))
        saveSession(response)
    }

    suspend fun resendConfirmation(email: String) {
        request("/auth/v1/resend", JSONObject().put("type", "signup").put("email", email))
    }

    suspend fun sendPasswordReset(email: String) {
        request("/auth/v1/recover", JSONObject().put("email", email))
    }

    /** Rotate the refresh token only when necessary, preventing concurrent refresh races. */
    suspend fun restoreSession(): Boolean = refreshMutex.withLock {
        if (tokenValid(sessionStore.readAccessToken())) return@withLock true
        val refreshToken = sessionStore.readRefreshToken() ?: return@withLock false
        return@withLock try {
            val response = request("/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token",refreshToken))
            saveSession(response)
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun signOut() {
        val accessToken = sessionStore.readAccessToken()
        try {
            if (accessToken != null) request("/auth/v1/logout", JSONObject(), accessToken)
        } catch (_: Exception) {
            // Local logout must work even if the network is unavailable.
        } finally {
            sessionStore.clear()
        }
    }

    private fun saveSession(json: JSONObject) {
        val access = json.optString("access_token")
        val refresh = json.optString("refresh_token")
        check(access.isNotBlank() && refresh.isNotBlank()) { "Не удалось получить сессию Supabase" }
        val email = json.optJSONObject("user")?.optString("email").orEmpty()
        sessionStore.save(access, refresh, email)
    }

    private suspend fun request(path: String, body: JSONObject, token: String? = null): JSONObject = withContext(Dispatchers.IO) {
        val connection = (URL(baseUrl + path).openConnection() as HttpURLConnection)
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15000
            connection.readTimeout = 20000
            connection.doOutput = true
            connection.setRequestProperty("apikey", publicKey)
            connection.setRequestProperty("Content-Type", "application/json")
            if (token != null) connection.setRequestProperty("Authorization", "Bearer $token")
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val text = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val result = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (status !in 200..299) {
                val detail = result.optString("msg").ifBlank {
                    result.optString("error_description").ifBlank {
                        result.optString("message").ifBlank { result.optString("error") }
                    }
                }
                throw AuthFailure(status, detail.ifBlank { "Ошибка сервера ($status)" })
            }
            result
        } finally {
            connection.disconnect()
        }
    }
}

class AuthFailure(val status: Int, message: String) : Exception(message)

/** Refresh and access tokens are encrypted using a non-exportable Android Keystore AES key. */
private class EncryptedSessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("vakclix_secure_session", Context.MODE_PRIVATE)
    private val alias = "vakclix_session_v1"

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
            alias, android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    fun save(access: String, refresh: String, email: String) {
        prefs.edit().putString("access", encrypt(access)).putString("refresh", encrypt(refresh))
            .apply {
                if (email.isNotBlank()) putString("email", encrypt(email))
            }.apply()
    }

    fun readEmail(): String? = read("email")
    fun readAccessToken(): String? = read("access")
    fun readRefreshToken(): String? = read("refresh")

    private fun read(name: String): String? = try {
        prefs.getString(name, null)?.let(::decrypt)
    } catch (_: Exception) { null }

    fun clear() { prefs.edit().clear().apply() }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val data = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(data, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val data = Base64.decode(value, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, data.copyOfRange(0, 12)))
        return String(cipher.doFinal(data.copyOfRange(12, data.size)), Charsets.UTF_8)
    }
}
