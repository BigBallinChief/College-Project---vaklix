package ru.vakliks.app.data.remote

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import ru.vakliks.app.BuildConfig
import ru.vakliks.app.data.Vacancy
import ru.vakliks.app.data.auth.AuthRepository
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** PostgREST + Supabase Storage with per-user JWT and server-enforced RLS. */
class SupabaseDatabase(context: Context) {
    private val auth = AuthRepository(context.applicationContext)
    private val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val apiKey = BuildConfig.SUPABASE_PUBLISHABLE_KEY

    data class Profile(val id: String, val fullName: String, val role: String, val city: String, val avatarPath: String?)
    data class Organization(val id: String, val ownerId: String, val name: String, val city: String, val description: String, val logoPath: String?)
    data class VacancyDraft(
        val title: String, val description: String, val city: String,
        val salaryFrom: Long?, val salaryTo: Long?, val salaryPeriod: String,
        val workSchedule: String, val hoursPerDay: Int?, val nightShifts: Boolean,
        val experience: String, val workFormat: String, val paymentFrequency: String,
        val employmentType: String, val specialization: String
    )

    private suspend fun execute(method: String, path: String, payload: String? = null,
                                contentType: String = "application/json", tokenRequired: Boolean = false,
                                extraHeaders: Map<String,String> = emptyMap()): String = withContext(Dispatchers.IO) {
        val token = if (tokenRequired) auth.databaseToken()
            ?: throw IllegalStateException("Сначала войдите в аккаунт") else auth.databaseToken()
        val conn = URL(base + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("apikey", apiKey)
            if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Accept", "application/json")
            for ((k,v) in extraHeaders) conn.setRequestProperty(k,v)
            if (payload != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type",contentType)
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            }
            val status = conn.responseCode
            val response = (if (status in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val json = runCatching { JSONObject(response) }.getOrNull()
                val msg = json?.optString("message")?.takeIf { it.isNotBlank() }
                    ?: json?.optString("msg")?.takeIf { it.isNotBlank() }
                    ?: response.take(200)
                throw IllegalStateException("Supabase ($status): $msg")
            }
            response
        } finally { conn.disconnect() }
    }

    private fun enc(value: String): String = Uri.encode(value)
    private fun rowResult(value: String): JSONObject = JSONArray(value).getJSONObject(0)
    private fun optional(json: JSONObject, field: String) = if (json.isNull(field)) null else json.optString(field).takeIf { it.isNotBlank() }
    private fun vacancy(json: JSONObject): Vacancy {
        val org = json.optJSONObject("organizations")
        val orgReviews = org?.optJSONArray("organization_reviews") ?: JSONArray()
        val reviewCount = orgReviews.length()
        val rating = if(reviewCount == 0) "—" else "%.1f".format((0 until reviewCount).map { orgReviews.getJSONObject(it).optInt("rating") }.average())
        val images = json.optJSONArray("vacancy_images") ?: JSONArray()
        val paths = (0 until images.length()).mapNotNull { i ->
            images.optJSONObject(i)?.let { o -> o.optInt("sort_order",0) to o.optString("storage_path") }
        }.sortedBy { it.first }.map { it.second }.filter { it.isNotBlank() }
        val from = json.optLong("salary_from",-1).takeIf { it >= 0 }
        val to = json.optLong("salary_to",-1).takeIf { it >= 0 }
        val period = when(json.optString("salary_period")) {"hour"->"час";"shift"->"смену";"service"->"услугу";else->"месяц"}
        val money = when {
            from != null && to != null -> "от $from ₽ до $to ₽ за $period"
            from != null -> "от $from ₽ за $period"
            to != null -> "до $to ₽ за $period"
            else -> "Зарплата не указана"
        }
        return Vacancy(id=json.getString("id"), title=json.optString("title"), salary=money,
            company=org?.optString("name") ?: "Организация", city=json.optString("city"),
            rating=rating, reviews="$reviewCount отзывов",
            summary=json.optString("description"), organizationId=json.optString("organization_id"),
            images=paths.map { publicImageUrl("vacancy-images",it) },
            workSchedule=json.optString("work_schedule"), experience=json.optString("experience"),
            workFormat=json.optString("work_format"), employmentType=json.optString("employment_type"),
            salaryFrom=from, salaryTo=to, salaryPeriod=json.optString("salary_period"),
            hoursPerDay=json.optInt("hours_per_day",0).takeIf { it > 0 },
            nightShifts=json.optBoolean("night_shifts"), paymentFrequency=json.optString("payment_frequency"),
            specialization=json.optString("specialization"), status=json.optString("status"),
            publishedAt=json.optString("published_at"))
    }

    private val vacancySelect = "id,organization_id,title,description,city,salary_from,salary_to,salary_period,work_schedule,hours_per_day,night_shifts,experience,work_format,payment_frequency,employment_type,specialization,status,published_at,organizations(name,organization_reviews(rating)),vacancy_images(storage_path,sort_order)"
    suspend fun vacancies(): List<Vacancy> {
        val json = JSONArray(execute("GET", "/rest/v1/vacancies?select=${enc(vacancySelect)}&status=eq.published&order=created_at.desc&limit=100"))
        return (0 until json.length()).map { vacancy(json.getJSONObject(it)) }
    }
    suspend fun vacancy(id:String): Vacancy? {
        val json = JSONArray(execute("GET", "/rest/v1/vacancies?select=${enc(vacancySelect)}&id=eq.${enc(id)}&limit=1"))
        return if (json.length()==0) null else vacancy(json.getJSONObject(0))
    }
    suspend fun myVacancies(organizationId:String):List<Vacancy> {
        val json=JSONArray(execute("GET","/rest/v1/vacancies?select=${enc(vacancySelect)}&organization_id=eq.${enc(organizationId)}&order=created_at.desc", tokenRequired=true))
        return (0 until json.length()).map { vacancy(json.getJSONObject(it)) }
    }
    suspend fun profile(): Profile {
        val userId = currentUserId()
        val rows=JSONArray(execute("GET","/rest/v1/profiles?select=id,full_name,role,city,avatar_path&id=eq.${enc(userId)}",tokenRequired=true))
        check(rows.length()>0) { "Профиль отсутствует. Проверьте регистрацию." }
        val obj=rows.getJSONObject(0)
        return Profile(userId,obj.optString("full_name"),obj.optString("role"),obj.optString("city"),optional(obj,"avatar_path"))
    }
    suspend fun currentUserId():String {
        val text=execute("GET","/auth/v1/user",tokenRequired=true)
        return JSONObject(text).getString("id")
    }
    suspend fun updateProfile(fullName:String,city:String,role:String?=null, avatarPath:String?=null) {
        val id=currentUserId()
        val body=JSONObject().put("full_name",fullName).put("city",city)
        if(role!=null) body.put("role",role)
        if(avatarPath!=null) body.put("avatar_path",avatarPath)
        execute("PATCH","/rest/v1/profiles?id=eq.${enc(id)}",body.toString(),tokenRequired=true)
    }
    suspend fun organizationsMine():List<Organization> {
        val id=currentUserId()
        val json=JSONArray(execute("GET","/rest/v1/organizations?select=id,owner_id,name,city,description,logo_path&owner_id=eq.${enc(id)}&order=created_at.desc",tokenRequired=true))
        return (0 until json.length()).map { objOrganization(json.getJSONObject(it)) }
    }
    suspend fun organization(id:String):Organization? {
        val json=JSONArray(execute("GET","/rest/v1/organizations?select=id,owner_id,name,city,description,logo_path&id=eq.${enc(id)}"))
        return if(json.length()==0) null else objOrganization(json.getJSONObject(0))
    }
    private fun objOrganization(o:JSONObject)=Organization(o.getString("id"),o.getString("owner_id"),o.optString("name"),o.optString("city"),o.optString("description"),optional(o,"logo_path"))
    suspend fun createOrganization(name:String,city:String): Organization {
        val body=JSONObject().put("owner_id",currentUserId()).put("name",name.trim()).put("city",city.trim())
        val json=execute("POST","/rest/v1/organizations?select=id,owner_id,name,city,description,logo_path",body.toString(),tokenRequired=true,extraHeaders=mapOf("Prefer" to "return=representation"))
        return objOrganization(rowResult(json))
    }
    suspend fun favorites():Set<String> {
        val id=currentUserId()
        val rows=JSONArray(execute("GET","/rest/v1/favorites?select=vacancy_id&user_id=eq.${enc(id)}",tokenRequired=true))
        return (0 until rows.length()).map { rows.getJSONObject(it).getString("vacancy_id") }.toSet()
    }
    suspend fun setFavorite(vacancyId:String, favorite:Boolean) {
        val id=currentUserId()
        if(favorite) {
            val body=JSONObject().put("user_id",id).put("vacancy_id",vacancyId)
            execute("POST","/rest/v1/favorites",body.toString(),tokenRequired=true,extraHeaders=mapOf("Prefer" to "resolution=ignore-duplicates"))
        } else execute("DELETE","/rest/v1/favorites?user_id=eq.${enc(id)}&vacancy_id=eq.${enc(vacancyId)}",tokenRequired=true)
    }
    suspend fun apply(vacancyId:String) {
        val body=JSONObject().put("applicant_id",currentUserId()).put("vacancy_id",vacancyId)
        execute("POST","/rest/v1/applications",body.toString(),tokenRequired=true)
    }
    suspend fun appliedIds():Set<String> {
        val json=JSONArray(execute("GET","/rest/v1/applications?select=vacancy_id",tokenRequired=true))
        return (0 until json.length()).map { json.getJSONObject(it).getString("vacancy_id") }.toSet()
    }
    suspend fun createVacancy(orgId:String,draft:VacancyDraft):String {
        val body=draftJson(draft).put("organization_id",orgId).put("created_by",currentUserId())
            .put("status","published").put("published_at",java.time.Instant.now().toString())
        val response=execute("POST","/rest/v1/vacancies?select=id",body.toString(),tokenRequired=true,extraHeaders=mapOf("Prefer" to "return=representation"))
        return rowResult(response).getString("id")
    }
    suspend fun editVacancy(id:String,draft:VacancyDraft) {
        execute("PATCH","/rest/v1/vacancies?id=eq.${enc(id)}",draftJson(draft).toString(),tokenRequired=true)
    }
    suspend fun archiveVacancy(id:String) {
        execute("PATCH","/rest/v1/vacancies?id=eq.${enc(id)}",
            JSONObject().put("status","archived").toString(),tokenRequired=true)
    }
    suspend fun deleteVacancy(id:String) {
        execute("DELETE","/rest/v1/vacancies?id=eq.${enc(id)}",tokenRequired=true)
    }
    private fun draftJson(d:VacancyDraft):JSONObject=JSONObject().put("title",d.title.trim()).put("description",d.description.trim())
        .put("city",d.city.trim()).put("salary_from",d.salaryFrom?:JSONObject.NULL)
        .put("salary_to",d.salaryTo?:JSONObject.NULL).put("salary_period",d.salaryPeriod)
        .put("work_schedule",d.workSchedule).put("hours_per_day",d.hoursPerDay?:JSONObject.NULL)
        .put("night_shifts",d.nightShifts).put("experience",d.experience)
        .put("work_format",d.workFormat).put("payment_frequency",d.paymentFrequency)
        .put("employment_type",d.employmentType).put("specialization",d.specialization)

    fun publicImageUrl(bucket:String,path:String):String = "$base/storage/v1/object/public/${enc(bucket)}/${path.split('/').joinToString("/") { enc(it) }}"
    suspend fun uploadPhoto(context:Context,uri:Uri,bucket:String,folder:String):String = withContext(Dispatchers.IO) {
        val resolver=context.contentResolver
        val mime=resolver.getType(uri)?.lowercase() ?: "image/jpeg"
        require(mime in setOf("image/jpeg","image/png","image/webp")) { "Допустимы только JPG, PNG и WebP" }
        val bytes=resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать изображение")
        require(bytes.size<=5*1024*1024) { "Фото должно быть не больше 5 МБ" }
        val extension=when(mime){"image/png"->"png";"image/webp"->"webp";else->"jpg"}
        val path="$folder/${UUID.randomUUID()}.$extension"
        val token=auth.databaseToken() ?: error("Войдите в аккаунт")
        val conn=URL("$base/storage/v1/object/${enc(bucket)}/$path").openConnection() as HttpURLConnection
        try {
            conn.requestMethod="POST";conn.connectTimeout=15000;conn.readTimeout=30000;conn.doOutput=true
            conn.setRequestProperty("apikey",apiKey);conn.setRequestProperty("Authorization","Bearer $token")
            conn.setRequestProperty("Content-Type",mime);conn.setRequestProperty("x-upsert","false")
            conn.outputStream.use{it.write(bytes)}
            val status=conn.responseCode
            if(status !in 200..299) error("Не удалось загрузить фото ($status): "+(conn.errorStream?.bufferedReader()?.use{it.readText()} ?: ""))
            path
        } finally {conn.disconnect()}
    }
    data class StoredPhoto(val path: String, val order: Int)
    suspend fun vacancyPhotos(id:String):List<StoredPhoto> {
        val rows = JSONArray(execute("GET","/rest/v1/vacancy_images?select=storage_path,sort_order&vacancy_id=eq.${enc(id)}&order=sort_order.asc",tokenRequired=true))
        return (0 until rows.length()).map { i -> rows.getJSONObject(i).let { o ->
            StoredPhoto(o.getString("storage_path"),o.getInt("sort_order"))
        } }
    }
    suspend fun removeVacancyPhoto(vacancyId:String, photo:StoredPhoto) {
        execute("DELETE","/rest/v1/vacancy_images?vacancy_id=eq.${enc(vacancyId)}&storage_path=eq.${enc(photo.path)}",tokenRequired=true)
        deleteObject("vacancy-images",photo.path)
    }
    suspend fun addVacancyImage(id:String,path:String,order:Int) {
        val body=JSONObject().put("vacancy_id",id).put("storage_path",path).put("sort_order",order)
        execute("POST","/rest/v1/vacancy_images",body.toString(),tokenRequired=true)
    }
    suspend fun clearVacancyImages(id:String) {
        execute("DELETE","/rest/v1/vacancy_images?vacancy_id=eq.${enc(id)}",tokenRequired=true)
    }
    suspend fun updateOrganizationLogo(orgId:String,path:String) {
        execute("PATCH","/rest/v1/organizations?id=eq.${enc(orgId)}",JSONObject().put("logo_path",path).toString(),tokenRequired=true)
    }
    data class Resume(val id:String, val title:String, val about:String, val experience:String,
                      val skills:String, val city:String, val desiredSalary:Long?)
    suspend fun myResume():Resume? {
        val user=currentUserId()
        val arr=JSONArray(execute("GET","/rest/v1/resumes?select=id,title,about,experience,skills,city,desired_salary&user_id=eq.${enc(user)}&order=created_at.desc&limit=1",tokenRequired=true))
        if(arr.length()==0)return null
        val o=arr.getJSONObject(0)
        return Resume(o.getString("id"),o.optString("title"),o.optString("about"),o.optString("experience"),
            o.optString("skills"),o.optString("city"),o.optLong("desired_salary",-1).takeIf{it>=0})
    }
    suspend fun saveResume(id:String?, title:String,about:String,experience:String,skills:String,city:String,salary:Long?) {
        val body=JSONObject().put("title",title).put("about",about).put("experience",experience)
            .put("skills",skills).put("city",city).put("desired_salary",salary?:JSONObject.NULL)
        if(id==null){body.put("user_id",currentUserId());execute("POST","/rest/v1/resumes",body.toString(),tokenRequired=true)}
        else execute("PATCH","/rest/v1/resumes?id=eq.${enc(id)}",body.toString(),tokenRequired=true)
    }
    data class Application(val id:String,val vacancyId:String,val status:String,val createdAt:String,val title:String,val conversationId:String?)
    suspend fun myApplications():List<Application> {
        val user=currentUserId()
        val arr=JSONArray(execute("GET","/rest/v1/applications?select=${enc("id,vacancy_id,status,created_at,vacancies(title)")}&applicant_id=eq.${enc(user)}&order=created_at.desc",tokenRequired=true))
        return (0 until arr.length()).map { val o=arr.getJSONObject(it)
            Application(o.getString("id"),o.getString("vacancy_id"),o.optString("status"),o.optString("created_at"),
                o.optJSONObject("vacancies")?.optString("title").orEmpty(),conversationForApplication(o.getString("id")))
        }
    }
    suspend fun deleteObject(bucket:String,path:String) {
        execute("DELETE","/storage/v1/object/${enc(bucket)}/${path.split('/').joinToString("/"){enc(it)}}",tokenRequired=true)
    }
    suspend fun deleteVacancyWithImages(id:String) {
        val job=vacancy(id)
        // Storage objects must be deleted while the parent vacancy still exists for RLS.
        if(job!=null) {
            val arr=JSONArray(execute("GET","/rest/v1/vacancy_images?select=storage_path&vacancy_id=eq.${enc(id)}",tokenRequired=true))
            (0 until arr.length()).forEach{ i -> deleteObject("vacancy-images",arr.getJSONObject(i).getString("storage_path")) }
        }
        deleteVacancy(id)
    }

    data class Review(val id:String, val rating:Int, val comment:String)
    suspend fun reviews(orgId:String):List<Review>{
        val arr=JSONArray(execute("GET","/rest/v1/organization_reviews?select=id,rating,comment&organization_id=eq.${enc(orgId)}&order=created_at.desc"))
        return (0 until arr.length()).map{val j=arr.getJSONObject(it);Review(j.getString("id"),j.getInt("rating"),j.optString("comment"))}
    }
    suspend fun addReview(orgId:String,rating:Int,comment:String){
        val j=JSONObject().put("organization_id",orgId).put("author_id",currentUserId()).put("rating",rating).put("comment",comment)
        execute("POST","/rest/v1/organization_reviews",j.toString(),tokenRequired=true)
    }
    data class EmployerApplication(val id:String,val status:String,val createdAt:String,val applicantId:String,val applicantName:String,val resume:Resume?,val conversationId:String?)
    suspend fun vacancyApplications(vacancyId:String):List<EmployerApplication>{
        val arr=JSONArray(execute("GET","/rest/v1/applications?select=id,applicant_id,status,created_at&vacancy_id=eq.${enc(vacancyId)}&order=created_at.desc",tokenRequired=true))
        return (0 until arr.length()).map{ val o=arr.getJSONObject(it)
            val user=o.getString("applicant_id")
            val name=person(user).optString("full_name").ifBlank { "Соискатель" }
            val resume=applicantResume(user)
            val chat=conversationForApplication(o.getString("id"))
            EmployerApplication(o.getString("id"),o.optString("status"),o.optString("created_at"),user,name,resume,chat)
        }
    }
    suspend fun setApplicationStatus(applicationId:String,status:String){
        require(status in setOf("pending","reviewed","accepted","rejected","completed"))
        execute("PATCH","/rest/v1/applications?id=eq.${enc(applicationId)}",JSONObject().put("status",status).toString(),tokenRequired=true)
    }


    data class ChatThread(
        val id: String, val applicationId: String, val title: String,
        val otherUserId: String, val otherName: String,
        val latestText: String, val unread: Int
    )
    data class ChatMessage(
        val id: String, val senderId: String, val body: String,
        val kind: String, val createdAt: String
    )

    /** Every conversation is tied to an application; RLS limits access to two participants. */
    suspend fun conversations(): List<ChatThread> {
        val uid = currentUserId()
        val rows = JSONArray(execute("GET", "/rest/v1/conversations?select=${enc("id,application_id,applicant_id,employer_id,applications(vacancies(title))")}&order=created_at.desc", tokenRequired=true))
        val out = mutableListOf<ChatThread>()
        for (i in 0 until rows.length()) {
            val c = rows.getJSONObject(i)
            val id = c.getString("id")
            val other = if (c.optString("applicant_id") == uid) c.getString("employer_id") else c.getString("applicant_id")
            val profile = person(other)
            val title = c.optJSONObject("applications")?.optJSONObject("vacancies")?.optString("title")?.takeIf { it.isNotBlank() } ?: "Вакансия"
            val recent = JSONArray(execute("GET", "/rest/v1/messages?select=body,created_at&conversation_id=eq.${enc(id)}&order=created_at.desc&limit=1", tokenRequired=true))
            val last = recent.optJSONObject(0)?.optString("body").orEmpty()
            out += ChatThread(id, c.getString("application_id"), title, other,
                profile.optString("full_name").ifBlank { "Пользователь" }, last, unreadForConversation(id, uid))
        }
        return out
    }

    suspend fun conversationForApplication(applicationId: String): String? {
        val rows = JSONArray(execute("GET", "/rest/v1/conversations?select=id&application_id=eq.${enc(applicationId)}&limit=1", tokenRequired=true))
        return rows.optJSONObject(0)?.optString("id")
    }

    suspend fun messages(conversationId: String): List<ChatMessage> {
        val rows = JSONArray(execute("GET", "/rest/v1/messages?select=id,sender_id,body,kind,created_at&conversation_id=eq.${enc(conversationId)}&order=created_at.asc&limit=300", tokenRequired=true))
        return (0 until rows.length()).map { rows.getJSONObject(it).let { m ->
            ChatMessage(m.getString("id"), m.getString("sender_id"), m.optString("body"),m.optString("kind"),m.optString("created_at"))
        } }
    }

    suspend fun sendMessage(conversationId: String, body: String) {
        val trimmed=body.trim()
        require(trimmed.isNotBlank() && trimmed.length <= 4000) { "Сообщение должно содержать от 1 до 4000 символов" }
        val data = JSONObject().put("conversation_id",conversationId).put("sender_id",currentUserId())
            .put("kind","text").put("body",trimmed)
        execute("POST","/rest/v1/messages",data.toString(),tokenRequired=true)
    }

    suspend fun markConversationRead(conversationId: String) {
        val data = JSONObject().put("conversation_id",conversationId).put("user_id",currentUserId())
            .put("read_at",java.time.Instant.now().toString())
        execute("POST","/rest/v1/conversation_reads?on_conflict=conversation_id,user_id",data.toString(),
            tokenRequired=true,extraHeaders=mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
    }

    suspend fun unreadCount(): Int {
        val uid=currentUserId()
        val rows = JSONArray(execute("GET","/rest/v1/conversations?select=id",tokenRequired=true))
        var count = 0
        for (i in 0 until rows.length()) count += unreadForConversation(rows.getJSONObject(i).getString("id"), uid)
        return count
    }

    private suspend fun unreadForConversation(conversationId: String, uid: String): Int {
        val readRows=JSONArray(execute("GET","/rest/v1/conversation_reads?select=read_at&conversation_id=eq.${enc(conversationId)}&user_id=eq.${enc(uid)}&limit=1",tokenRequired=true))
        val since=readRows.optJSONObject(0)?.optString("read_at")
        val query="/rest/v1/messages?select=id&conversation_id=eq.${enc(conversationId)}&sender_id=neq.${enc(uid)}" +
            (if (since.isNullOrBlank()) "" else "&created_at=gt.${enc(since)}") + "&limit=100"
        return JSONArray(execute("GET",query,tokenRequired=true)).length()
    }

    suspend fun person(userId: String): JSONObject {
        val arr=JSONArray(execute("GET","/rest/v1/profiles?select=id,full_name,avatar_path,city&id=eq.${enc(userId)}&limit=1",tokenRequired=true))
        return arr.optJSONObject(0) ?: JSONObject().put("full_name","Пользователь")
    }

    suspend fun applicantResume(userId:String): Resume? {
        val arr=JSONArray(execute("GET","/rest/v1/resumes?select=id,title,about,experience,skills,city,desired_salary&user_id=eq.${enc(userId)}&order=created_at.desc&limit=1",tokenRequired=true))
        val o=arr.optJSONObject(0) ?: return null
        return Resume(o.getString("id"),o.optString("title"),o.optString("about"),o.optString("experience"),
            o.optString("skills"),o.optString("city"),o.optLong("desired_salary",-1).takeIf{it>=0})
    }


    /** Only public fields are requested; profile RLS decides whether a user may be viewed. */
    suspend fun publicProfile(userId:String): Profile? {
        val arr=JSONArray(execute("GET","/rest/v1/profiles?select=id,full_name,city,avatar_path&id=eq.${enc(userId)}&limit=1",tokenRequired=true))
        val p=arr.optJSONObject(0) ?: return null
        return Profile(userId,p.optString("full_name").ifBlank { "Пользователь" },"",p.optString("city"),optional(p,"avatar_path"))
    }

    suspend fun vacancyPublisher(vacancyId:String): String? {
        val rows=JSONArray(execute("GET","/rest/v1/vacancies?select=created_by&id=eq.${enc(vacancyId)}&limit=1"))
        return rows.optJSONObject(0)?.optString("created_by")?.takeIf { it.isNotBlank() }
    }

    suspend fun organizationsByOwner(ownerId:String): List<Organization> {
        val arr=JSONArray(execute("GET","/rest/v1/organizations?select=id,owner_id,name,city,description,logo_path&owner_id=eq.${enc(ownerId)}&order=created_at.desc"))
        return (0 until arr.length()).map { objOrganization(arr.getJSONObject(it)) }
    }

    data class WorkerReview(val id:String,val rating:Int,val comment:String,val createdAt:String)
    suspend fun workerReviews(workerId:String):List<WorkerReview> {
        val arr=JSONArray(execute("GET","/rest/v1/worker_reviews?select=id,rating,comment,created_at&worker_id=eq.${enc(workerId)}&order=created_at.desc"))
        return (0 until arr.length()).map { val o=arr.getJSONObject(it)
            WorkerReview(o.getString("id"),o.optInt("rating"),o.optString("comment"),o.optString("created_at"))
        }
    }
    suspend fun hasWorkerReview(applicationId:String):Boolean {
        val arr=JSONArray(execute("GET","/rest/v1/worker_reviews?select=id&application_id=eq.${enc(applicationId)}&limit=1",tokenRequired=true))
        return arr.length()>0
    }
    suspend fun addWorkerReview(applicationId:String,workerId:String,rating:Int,comment:String) {
        require(rating in 1..5 && comment.trim().isNotEmpty())
        val j=JSONObject().put("application_id",applicationId).put("worker_id",workerId)
            .put("author_id",currentUserId()).put("rating",rating).put("comment",comment.trim())
        execute("POST","/rest/v1/worker_reviews",j.toString(),tokenRequired=true)
    }

}
