package ru.vakliks.app.navigation

import android.widget.Toast
import android.content.Intent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import ru.vakliks.app.data.VacancyFilters
import ru.vakliks.app.data.auth.AuthRepository
import ru.vakliks.app.data.auth.AuthFailure
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import ru.vakliks.app.ui.screens.*

/** Supabase Auth + PostgREST + Storage. App navigation uses real database UUIDs. */
@Composable
fun NavGraph(navController: NavHostController = rememberNavController()) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val auth = remember(context) { AuthRepository(context) }
    var busy by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }
    var registrationEmail by remember { mutableStateOf("") }
    var vacancyFilters by remember { mutableStateOf(VacancyFilters()) }
    var accountEmail by remember { mutableStateOf(auth.currentEmail()) }
    fun friendlyError(error: Throwable): String {
        val message = error.message.orEmpty()
        return when {
            message.contains("already registered", true) || message.contains("already been registered", true) -> "Такая почта уже зарегистрирована"
            message.contains("invalid login credentials", true) -> "Неверная почта или пароль"
            message.contains("email not confirmed", true) -> "Подтвердите электронную почту перед входом"
            message.contains("rate limit", true) || (error is AuthFailure && error.status == 429) -> "Слишком много попыток. Повторите позже"
            message.contains("network", true) || error is java.io.IOException -> "Нет соединения с сервером. Проверьте интернет"
            else -> message.ifBlank { "Не удалось выполнить запрос. Повторите попытку" }
        }
    }

    val go: (String) -> Unit = { route ->
        navController.navigate(route) { launchSingleTop = true }
    }
    LaunchedEffect(Unit) {
        if (auth.restoreSession()) {
            accountEmail = auth.currentEmail()
            navController.navigate(Screen.Home.route) {
                popUpTo(Screen.Welcome.route) { inclusive = true }
                launchSingleTop = true
            }
        }
    }
    fun navigateFromAuth(destination: String) {
        navController.navigate(destination) {
            popUpTo(Screen.Welcome.route) { inclusive = true }
            launchSingleTop = true
        }
    }
    NavHost(navController = navController, startDestination = Screen.Welcome.route) {
        composable(Screen.Welcome.route) {
            WelcomeScreen(onRegister = { go(Screen.Register.route) }, onLogin = { go(Screen.Login.route) })
        }
        composable(Screen.Login.route) {
            LoginScreen(onLogin = { email, password ->
                scope.launch {
                    busy = true; authError = null
                    try { auth.signIn(email, password); accountEmail = auth.currentEmail(); navigateFromAuth(Screen.Home.route) }
                    catch (e: Exception) { authError = friendlyError(e) }
                    finally { busy = false }
                }
            }, onRegister = { authError = null; go(Screen.Register.route) },
                onForgotPassword = { email ->
                    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                        authError = "Введите свою электронную почту для восстановления пароля"
                    } else scope.launch {
                        busy = true; authError = null
                        try {
                            auth.sendPasswordReset(email)
                            Toast.makeText(context, "Если адрес зарегистрирован, письмо отправлено", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) { authError = friendlyError(e) }
                        finally { busy = false }
                    }
                }, isLoading = busy, errorMessage = authError)
        }
        // The original error screens remain as visual references but are not used by real auth.
        composable(Screen.LoginError.route) {
            LoginErrorScreen(onLogin = { go(Screen.Login.route) }, onRegister = { go(Screen.Register.route) })
        }
        composable(Screen.Register.route) {
            RegisterScreen(onRegister = { email, password, fullName ->
                scope.launch {
                    busy = true; authError = null
                    try {
                        val result = auth.signUp(email, password, fullName)
                        registrationEmail = email
                        if (result.needsEmailConfirmation) go(Screen.VerifyEmail.route)
                        else { accountEmail = auth.currentEmail(); navigateFromAuth(Screen.Home.route) }
                    } catch (e: Exception) { authError = friendlyError(e) }
                    finally { busy = false }
                }
            }, onLogin = { authError = null; go(Screen.Login.route) },
                isLoading = busy, errorMessage = authError)
        }
        composable(Screen.RegisterError.route) {
            RegisterErrorScreen(onVerify = { go(Screen.Register.route) }, onLogin = { go(Screen.Login.route) })
        }
        composable(Screen.VerifyEmail.route) {
            VerifyEmailScreen(email = registrationEmail,
                onOpenMail = {
                    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL)
                    try { context.startActivity(intent) }
                    catch (_: Exception) { Toast.makeText(context, "Откройте почтовое приложение и подтвердите адрес", Toast.LENGTH_LONG).show() }
                },
                onResend = {
                    scope.launch {
                        if (registrationEmail.isNotBlank()) {
                            try { auth.resendConfirmation(registrationEmail)
                                Toast.makeText(context, "Письмо отправлено повторно", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) { Toast.makeText(context, friendlyError(e), Toast.LENGTH_LONG).show() }
                        }
                    }
                }, onLogin = { authError = null; go(Screen.Login.route) })
        }
        composable(Screen.Home.route) {
            HomeScreen(onNavigate=go,onVacancy={go("vacancy_detail/$it")},
                onCompany={go("organization/$it")},onAll={go(Screen.VacancyList.route)},onResume={go(Screen.UserProfile.route)})
        }
        composable(Screen.VacancyList.route) {
            VacancyListScreen(onNavigate=go,onOpen={go("vacancy_detail/$it")},
                onCompany={go("organization/$it")},onNoResults={go(Screen.NoResults.route)},filters=vacancyFilters)
        }
        composable("vacancy_detail/{vacancyId}") { entry ->
            VacancyDetailScreen(vacancyId=entry.arguments?.getString("vacancyId").orEmpty(),
                onNavigate=go,onCompany={go("organization/$it")})
        }
        composable(Screen.Messages.route) {
            MessagesScreen(onNavigate = go, onOpen = { go("chat/$it") }, onUser = { go("user/$it") })
        }
        composable("chat/{conversationId}") { entry ->
            ChatScreen(conversationId = entry.arguments?.getString("conversationId").orEmpty(),
                onBack = { navController.popBackStack() }, onUser = { go("user/$it") })
        }
        composable("user/{userId}") { entry ->
            PublicUserScreen(userId=entry.arguments?.getString("userId").orEmpty(),
                onBack={navController.popBackStack()},onOrganization={go("organization/$it")})
        }
        composable("help") { HelpScreen(onBack={navController.popBackStack()}) }
        composable(Screen.Filters.route) {
            FiltersScreen(initial=vacancyFilters,onApply={vacancyFilters=it;go(Screen.VacancyList.route)},onFavorites={go(Screen.Favorites.route)})
        }
        composable(Screen.NoResults.route) { NoResultsScreen(onNavigate = go) }
        composable(Screen.Favorites.route) {
            FavoritesScreen(onNavigate=go,onOpen={go("vacancy_detail/$it")},onEmpty={go(Screen.EmptyFavorites.route)})
        }
        composable(Screen.EmptyFavorites.route) {
            EmptyFavoritesScreen(onNavigate=go,onAll={go(Screen.VacancyList.route)})
        }
        composable("employer_applications/{vacancyId}") { entry ->
            EmployerApplicationsScreen(entry.arguments?.getString("vacancyId").orEmpty(),
                onBack={navController.popBackStack()}, onChat={go("chat/$it")}, onUser={go("user/$it")})
        }
        composable("resume") { ResumeScreen(onBack={go(Screen.UserProfile.route)}) }
        composable("applications") { MyApplicationsScreen(onNavigate=go,onOpen={go("vacancy_detail/$it")}) }
        composable(Screen.UserProfile.route) {
            UserProfileScreen(onNavigate = go, onResume = {
                go("resume")
            }, onOrganization = { go(Screen.OrganizationProfile.route) }, email = accountEmail, onLogout = {
                scope.launch {
                    auth.signOut()
                    accountEmail = null
                    navController.navigate(Screen.Welcome.route) {
                        popUpTo(Screen.Home.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            })
        }
        composable(Screen.OrganizationProfile.route) {
            OrganizationProfileScreen(organizationId=null,onNavigate=go,
                onEdit={go("edit_vacancy/$it")},onAdd={go("add_vacancy/$it")},onOpen={go("vacancy_detail/$it")})
        }
        composable("organization/{organizationId}") { entry ->
            OrganizationProfileScreen(organizationId=entry.arguments?.getString("organizationId"),onNavigate=go,
                onEdit={go("edit_vacancy/$it")},onAdd={go("add_vacancy/$it")},onOpen={go("vacancy_detail/$it")})
        }
        composable("add_vacancy/{organizationId}") { entry ->
            VacancyEditorScreen(organizationId=entry.arguments?.getString("organizationId"),vacancyId=null,
                onDone={go(Screen.OrganizationProfile.route)},onFavorites={go(Screen.Favorites.route)})
        }
        composable("edit_vacancy/{vacancyId}") { entry ->
            VacancyEditorScreen(organizationId=null,vacancyId=entry.arguments?.getString("vacancyId"),
                onDone={go(Screen.OrganizationProfile.route)},onFavorites={go(Screen.Favorites.route)})
        }
        composable(Screen.AddVacancy.route) {
            OrganizationProfileScreen(organizationId=null,onNavigate=go,onEdit={go("edit_vacancy/$it")},onAdd={go("add_vacancy/$it")},onOpen={go("vacancy_detail/$it")})
        }
        composable(Screen.EditVacancy.route) {
            OrganizationProfileScreen(organizationId=null,onNavigate=go,onEdit={go("edit_vacancy/$it")},onAdd={go("add_vacancy/$it")},onOpen={go("vacancy_detail/$it")})
        }
    }
}
