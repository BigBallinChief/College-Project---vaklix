package ru.vakliks.app.navigation

/** Один маршрут на каждый из 17 приложенных макетов. */
sealed class Screen(val route: String) {
    data object Welcome : Screen("welcome")
    data object Login : Screen("login")
    data object LoginError : Screen("login_error")
    data object Register : Screen("register")
    data object RegisterError : Screen("register_error")
    data object VerifyEmail : Screen("verify_email")
    data object Home : Screen("home")
    data object VacancyList : Screen("jobs")
    data object VacancyDetail : Screen("vacancy_detail")
    data object Filters : Screen("filters")
    data object Messages : Screen("messages")
    data object NoResults : Screen("no_results")
    data object Favorites : Screen("favorites")
    data object EmptyFavorites : Screen("empty_favorites")
    data object UserProfile : Screen("profile")
    data object OrganizationProfile : Screen("organization")
    data object AddVacancy : Screen("add_vacancy")
    data object EditVacancy : Screen("edit_vacancy")
}
