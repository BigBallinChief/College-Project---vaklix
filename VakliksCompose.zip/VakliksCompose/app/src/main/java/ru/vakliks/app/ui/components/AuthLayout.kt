package ru.vakliks.app.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ru.vakliks.app.R
import ru.vakliks.app.ui.theme.Dimens

/** Форма едина для обычного и error-состояния, чтобы слои совпадали. */
@Composable
fun AuthLayout(
    isRegistration: Boolean,
    isError: Boolean,
    onSubmit: (String, String, String) -> Unit,
    onSwitch: () -> Unit,
    onForgot: (String) -> Unit,
    isSubmitting: Boolean = false,
    serverError: String? = null,
) {
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(if (isError) "example@email.ru" else "") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }
    AppPage {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .navigationBarsPadding().padding(bottom = Dimens.lg),
        ) {
            Box(Modifier.fillMaxWidth().height(
                when { isError && isRegistration -> 450.dp; isError -> 367.dp; isRegistration -> 475.dp; else -> 490.dp }
            )) {
                MascotWatermark(Modifier.size(390.dp).align(Alignment.TopStart).offset(x = (-115).dp, y = (-110).dp))
                MascotArtwork(
                    drawable = if (isRegistration) R.drawable.mascot_register else R.drawable.mascot_login,
                    modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp),
                    fadeBottom = true,
                )
            }
            Column(
                Modifier.fillMaxWidth().padding(horizontal = Dimens.regular),
                verticalArrangement = Arrangement.spacedBy(Dimens.regular),
            ) {
                Text(
                    if (isRegistration) buildAnnotatedString {
                        append("Ищи в ")
                        withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary)) { append("Вакликс!") }
                    } else buildAnnotatedString { append("Вход в аккаунт") },
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                if (isRegistration) {
                    LabeledField("Ваше имя", fullName, { fullName = it }, "Как к вам обращаться")
                }
                LabeledField(
                    "Электронная почта", email, { email = it }, "example@email.ru",
                    isError = isError, keyboardType = KeyboardType.Email,
                )
                LabeledField("Пароль", password, { password = it }, "Введите пароль", password = true)
                if (isRegistration) {
                    LabeledField("Подтверждение пароля", confirm, { confirm = it }, "Повторите пароль", password = true)
                } else {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                        LinkButton("Забыли пароль?", { onForgot(email.trim()) })
                    }
                }
                val validation = localError ?: serverError
                if (validation != null) {
                    Text(validation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                if (isSubmitting) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(Modifier.height(when { isError -> 6.dp; isRegistration -> 12.dp; else -> 22.dp }))
                PrimaryButton(if (isSubmitting) "Подождите…" else if (isRegistration) "Создать аккаунт" else "Войти", onClick = {
                    localError = when {
                        email.trim().isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "Введите корректную электронную почту"
                        password.length < 6 -> "Пароль должен содержать не менее 6 символов"
                        isRegistration && fullName.isBlank() -> "Введите имя"
                        isRegistration && password != confirm -> "Пароли не совпадают"
                        else -> null
                    }
                    if (localError == null && !isSubmitting) onSubmit(email.trim(), password, fullName.trim())
                }, modifier = Modifier.fillMaxWidth(), enabled = !isSubmitting)
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    LinkButton(if (isRegistration) "Войти" else "Создать аккаунт", onSwitch)
                }
            }
        }
    }
}
