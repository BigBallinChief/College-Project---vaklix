package ru.vakliks.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun CatalogTopBar(
    search: String,
    onSearch: (String) -> Unit,
    onFavorites: () -> Unit,
    onFilters: () -> Unit,
    isFilters: Boolean = false,
    showGreeting: Boolean = true,
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
        if (showGreeting) Greeting() else Text("Фильтры", modifier = Modifier.padding(start = Dimens.lg),
            style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
        SearchHeader(search, onSearch, onFavorites = onFavorites, onFilters = onFilters, filterActive = isFilters)
    }
}

@Composable
fun QuickSearchChips(onSelect: (String) -> Unit, selected: String = "Краснодар") {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(Dimens.xxs),
    ) {
        listOf("Краснодар", "Опыт", "Район", "График", "Рабочие часы", "Тип занятости").forEach { text ->
            FilterChip(text, selected = text == selected, onClick = { onSelect(text) })
        }
    }
}

@Composable
fun SortingRow() {
    var sort by remember { mutableStateOf(true) }
    var period by remember { mutableStateOf(true) }
    Row(horizontalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
        DropDownPill(if (sort) "По соответствию" else "По дате", onClick = { sort = !sort })
        DropDownPill(if (period) "За всё время" else "За неделю", onClick = { period = !period })
    }
}
