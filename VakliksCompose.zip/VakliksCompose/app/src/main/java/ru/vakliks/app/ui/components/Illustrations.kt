package ru.vakliks.app.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import ru.vakliks.app.R

@Composable
fun MascotArtwork(@DrawableRes drawable: Int, modifier: Modifier = Modifier, fadeBottom: Boolean = false) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(drawable),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit,
        )
        if (fadeBottom) {
            Box(
                Modifier.fillMaxWidth().fillMaxHeight(0.40f).align(Alignment.BottomCenter).background(
                    Brush.verticalGradient(
                        listOf(MaterialTheme.colorScheme.background.copy(alpha = 0f), MaterialTheme.colorScheme.background),
                    ),
                ),
            )
        }
    }
}

@Composable
fun MascotWatermark(modifier: Modifier = Modifier) {
    Image(
        painterResource(R.drawable.mascot_face),
        contentDescription = null,
        modifier = modifier.alpha(0.055f),
        contentScale = ContentScale.Fit,
    )
}
