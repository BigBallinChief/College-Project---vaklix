package ru.vakliks.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.vakliks.app.ui.theme.Dimens

@Composable
private fun FormTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onBackground)
}

@Composable
private fun FormDropDown(name: String, options: List<String>) {
    var selected by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
        FormTitle(name)
        Row(
            Modifier.fillMaxWidth().height(Dimens.inputHeight)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(Dimens.inputRadius))
                .clickable { show = !show }.padding(horizontal = Dimens.regular),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(selected.ifBlank { "Выберите из списка" }, modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = if (selected.isBlank()) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurfaceVariant)
            // TODO: Заменить на кастомную SVG
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Раскрыть", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (show) options.forEach { option ->
            FilterChip(option, selected == option, { selected = option; show = false })
        }
    }
}

@Composable
private fun FormChipRow(options: List<String>) {
    var selected by remember { mutableStateOf("") }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(Dimens.xxs),
    ) {
        options.forEach { option -> FilterChip(option, selected = option == selected, onClick = { selected = option }) }
    }
}

/** Контент экрана создания и редактирования вакансии; кнопки живут в экране-обёртке. */
@Composable
fun JobFormContent(isEdit: Boolean, onFavorites: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var title by remember { mutableStateOf(if (isEdit) "Автокурьер в Лавку" else "") }
    var salary by remember { mutableStateOf(if (isEdit) "от 80 000 ₽" else "") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = Dimens.regular),
        verticalArrangement = Arrangement.spacedBy(Dimens.md),
    ) {
        Spacer(Modifier.height(Dimens.toolbarTop))
        FormTitle("Добавление вакансии")
        SearchHeader(query, { query = it }, placeholder = "Профессия, должность или компания", onFavorites = onFavorites)
        Row(horizontalArrangement = Arrangement.spacedBy(Dimens.xs)) {
            repeat(5) {
                Box(
                    Modifier.weight(1f).height(86.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(Dimens.sm))
                        .clickable { /* Заглушка добавления фото */ },
                    contentAlignment = Alignment.Center,
                ) {
                    // TODO: Заменить на кастомную SVG
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Добавить фото",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(29.dp))
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
            FormTitle("Регион")
            Row { FilterChip("Краснодар", selected = true, onClick = {}) }
        }
        Column(verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
            FormTitle("Название")
            AppTextField(title, { title = it }, "Название")
        }
        Column(verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
            FormTitle("Зарплата / награда")
            AppTextField(salary, { salary = it }, "От")
            FormChipRow(listOf("За месяц", "За смену", "За час", "За услугу"))
        }
        FormDropDown("График работы", listOf("5/2", "2/2", "6/1", "3/3", "Другое"))
        FormChipRow(listOf("5/2", "2/2", "6/1", "3/3", "Другое"))
        FormDropDown("Рабочие часы в день", listOf("4 часа", "6 часов", "8 часов", "12 часов"))
        FormChipRow(listOf("Вечерние или ночные смены"))
        FormDropDown("Опыт работы", listOf("Нет опыта", "От 1 года до 3 лет", "От 3 до 6 лет", "Более 6 лет"))
        FormDropDown("Формат работы", listOf("Удалённо", "Гибрид", "На месте работодателя", "Разъездной"))
        FormDropDown("Частота выплат", listOf("Два раза в месяц", "Раз в неделю", "Раз в месяц", "Ежедневно"))
        FormDropDown("Тип занятости", listOf("Полная занятость", "Вахта", "Частичная занятость", "Подработка"))
        FormDropDown("Специализация", listOf("Курьер", "Логистика", "Продажи", "Другое"))
        FormDropDown("Компания", listOf("Yandex LLC", "Другая организация"))
        FormDropDown("Отрасль компании", listOf("Доставка", "Торговля", "Логистика"))
        Spacer(Modifier.height(150.dp))
    }
}
