package ru.vakliks.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun JobFormScaffold(isEdit: Boolean, onDone: () -> Unit, onDelete: () -> Unit, onFavorites: () -> Unit) {
    var saved by remember { mutableStateOf(false) }
    AppPage {
        JobFormContent(isEdit = isEdit, onFavorites = onFavorites)
        Column(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .navigationBarsPadding().padding(horizontal = Dimens.regular, vertical = Dimens.sm),
            verticalArrangement = Arrangement.spacedBy(Dimens.xxs),
        ) {
            PrimaryButton(
                if (saved) "Сохранено (демо)" else if (isEdit) "Сохранить изменения" else "Создать",
                onClick = { saved = true; onDone() },
                modifier = Modifier.fillMaxWidth(), compact = true,
            )
            if (isEdit) {
                Box(
                    Modifier.fillMaxWidth().height(Dimens.chipHeight)
                        .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(Dimens.inputRadius)),
                    contentAlignment = Alignment.Center,
                ) {
                    LinkButton("Удалить", onClick = onDelete)
                }
            }
        }
    }
}
