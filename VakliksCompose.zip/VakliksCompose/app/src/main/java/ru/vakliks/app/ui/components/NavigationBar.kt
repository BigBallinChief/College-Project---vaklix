package ru.vakliks.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import ru.vakliks.app.data.remote.SupabaseDatabase
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import ru.vakliks.app.ui.theme.Dimens

/** Нижняя плавающая навигация со всеми пятью пунктами макета. */
@Composable
fun AppBottomBar(current: String, onNavigate: (String) -> Unit, modifier: Modifier = Modifier) {
    val tabs: List<Pair<String, ImageVector>> = listOf(
        "home" to Icons.Default.Home,
        "jobs" to Icons.Default.Search,
        "favorites" to Icons.Default.FavoriteBorder,
        "messages" to Icons.Default.ChatBubbleOutline,
        "profile" to Icons.Default.PersonOutline,
    )
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    var unread by remember { mutableIntStateOf(0) }
    LaunchedEffect(current) {
        while (true) {
            unread = runCatching { db.unreadCount() }.getOrDefault(0)
            delay(15000)
        }
    }
    Row(
        modifier = modifier
            .navigationBarsPadding()
            .padding(bottom = Dimens.sm)
            .height(Dimens.navHeight)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(Dimens.inputRadius))
            .padding(horizontal = Dimens.xs),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        tabs.forEach { (route, symbol) ->
            val selected = current == route
            Box(
                Modifier.size(52.dp).background(
                    if (selected) MaterialTheme.colorScheme.primaryContainer else androidx.compose.ui.graphics.Color.Transparent,
                    CircleShape,
                ).clickable { onNavigate(route) },
                contentAlignment = Alignment.Center,
            ) {
                // TODO: Заменить на кастомную SVG
                Icon(
                    imageVector = symbol,
                    contentDescription = route,
                    modifier = Modifier.size(29.dp),
                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (route == "messages" && unread > 0) {
                    Box(Modifier.align(Alignment.TopEnd)
                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                        .padding(horizontal = 5.dp, vertical = 2.dp)) {
                        androidx.compose.material3.Text(
                            text = if (unread > 99) "99+" else "$unread",
                            color = MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
