package ru.vakliks.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import ru.vakliks.app.ui.theme.Dimens
import coil.compose.AsyncImage

@Composable
fun RemoteImage(url:String?, modifier:Modifier=Modifier, description:String?=null) {
    if (!url.isNullOrBlank()) AsyncImage(model=url, contentDescription=description, modifier=modifier.clip(RoundedCornerShape(Dimens.sm)), contentScale=ContentScale.Crop)
}
