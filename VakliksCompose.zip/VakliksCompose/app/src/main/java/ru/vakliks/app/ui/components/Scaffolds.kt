package ru.vakliks.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.data.auth.AuthRepository
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun AppPage(
    currentTab: String? = null,
    onNavigate: (String) -> Unit = {},
    content: @Composable BoxScope.() -> Unit,
) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        content()
        if (currentTab != null) AppBottomBar(
            current = currentTab,
            onNavigate = onNavigate,
            modifier = Modifier.align(Alignment.BottomCenter).widthIn(max = 340.dp).fillMaxWidth(),
        )
    }
}

@Composable
fun SearchHeader(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String = "Профессия или компания",
    filterActive: Boolean = false,
    onFavorites: () -> Unit,
    onFilters: (() -> Unit)? = null,
) {
    Row(
        Modifier.fillMaxWidth().height(Dimens.chipHeight),
        horizontalArrangement = Arrangement.spacedBy(Dimens.xxs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            Modifier.weight(1f).fillMaxHeight().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(Dimens.inputRadius))
                .padding(horizontal = Dimens.lg),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // TODO: Заменить на кастомную SVG
            Icon(Icons.Default.Search, contentDescription = "Поиск", modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(Dimens.sm))
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                modifier = Modifier.weight(1f),
                decorationBox = { inner -> Box { if (value.isBlank()) Text(placeholder, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline); inner() } },
            )
        }
        Box(
            Modifier.size(Dimens.chipHeight).background(MaterialTheme.colorScheme.surfaceVariant, CircleShape).clickable(onClick = onFavorites),
            contentAlignment = Alignment.Center,
        ) {
            // TODO: Заменить на кастомную SVG
            Icon(Icons.Default.StarBorder, contentDescription = "Избранное", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (onFilters != null) {
            Box(
                Modifier.size(Dimens.chipHeight).background(
                    if (filterActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    CircleShape,
                ).clickable(onClick = onFilters),
                contentAlignment = Alignment.Center,
            ) {
                // TODO: Заменить на кастомную SVG
                Icon(Icons.Default.Tune, contentDescription = "Фильтры", tint = if (filterActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun Greeting() {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val auth = remember(context) { AuthRepository(context) }
    var displayName by remember { mutableStateOf(auth.currentEmail()?.substringBefore('@').orEmpty()) }
    LaunchedEffect(context, auth.currentEmail()) {
        try {
            val savedName = db.profile().fullName.trim()
            if (savedName.isNotBlank()) displayName = savedName.substringBefore(' ')
        } catch (_: Exception) { /* Keep the account-specific email fallback offline. */ }
    }
    Row(Modifier.fillMaxWidth().padding(start = Dimens.lg), verticalAlignment = Alignment.CenterVertically) {
        Text("Привет! ", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(displayName.ifBlank { "Пользователь" }, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
fun SectionHeading(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = Dimens.regular), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
        if (action != null) Text(action, modifier = Modifier.clickable(onClick = onAction), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
