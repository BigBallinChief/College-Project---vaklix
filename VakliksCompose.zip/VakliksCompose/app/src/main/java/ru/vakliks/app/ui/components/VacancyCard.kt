package ru.vakliks.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.vakliks.app.data.Vacancy
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun VacancyCard(
    vacancy: Vacancy,
    compact: Boolean = false,
    isFavorite: Boolean = false,
    onOpen: () -> Unit,
    onFavorite: () -> Unit,
    onApply: () -> Unit,
    onCompany: () -> Unit = onOpen,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(Dimens.cardRadius))
            .clickable(onClick = onOpen)
            .padding(Dimens.md),
        verticalArrangement = Arrangement.spacedBy(Dimens.xxs),
    ) {
        if (vacancy.images.isNotEmpty() && !compact) {
            RemoteImage(vacancy.images.first(), Modifier.fillMaxWidth().height(112.dp), "Фото вакансии")
        }
        Text(
            vacancy.title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            vacancy.salary,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(if (compact) Dimens.sm else Dimens.xxs))
        Text(vacancy.city, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
            // TODO: Заменить на кастомную SVG
            Icon(Icons.Default.CheckCircle, contentDescription = "Проверено", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
            Text(vacancy.company, modifier = Modifier.clickable(onClick = onCompany).weight(1f, fill = false),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            // TODO: Заменить на кастомную SVG
            Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.tertiary)
            Text("${vacancy.rating} · ${vacancy.reviews}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(vacancy.summary, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = if (compact) 3 else 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.weight(1f, fill = false))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
            Box(
                Modifier.weight(1f).height(35.dp)
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(Dimens.inputRadius))
                    .clickable(onClick = onApply),
                contentAlignment = Alignment.Center,
            ) {
                Text("Откликнуться", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimary,
                    maxLines = 1)
            }
            Box(
                Modifier.size(35.dp).background(MaterialTheme.colorScheme.surfaceVariant, CircleShape).clickable(onClick = onFavorite),
                contentAlignment = Alignment.Center,
            ) {
                // TODO: Заменить на кастомную SVG
                Icon(if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "В избранное", modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
