package ru.vakliks.app.ui.screens

import androidx.compose.runtime.Composable
import ru.vakliks.app.ui.components.JobFormScaffold

@Composable
fun AddVacancyScreen(onDone: () -> Unit, onFavorites: () -> Unit) {
    JobFormScaffold(isEdit = false, onDone = onDone, onDelete = onDone, onFavorites = onFavorites)
}
