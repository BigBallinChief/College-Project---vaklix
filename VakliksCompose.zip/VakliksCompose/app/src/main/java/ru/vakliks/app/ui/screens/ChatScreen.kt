package ru.vakliks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.AppPage
import ru.vakliks.app.ui.components.RemoteImage
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun ChatScreen(conversationId: String, onBack: () -> Unit, onUser: (String) -> Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope = rememberCoroutineScope()
    val scroll = rememberLazyListState()
    var myId by remember { mutableStateOf("") }
    var otherId by remember { mutableStateOf("") }
    var otherAvatar by remember { mutableStateOf<String?>(null) }
    var header by remember { mutableStateOf("Переписка") }
    var title by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf<List<SupabaseDatabase.ChatMessage>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var sending by remember { mutableStateOf(false) }

    LaunchedEffect(conversationId) {
        try {
            myId = db.currentUserId()
            val conversation = db.conversations().firstOrNull { it.id == conversationId }
                ?: throw IllegalStateException("Переписка недоступна")
            header = conversation.otherName
            otherId = conversation.otherUserId
            otherAvatar = db.publicProfile(otherId)?.avatarPath
            title = conversation.title
            while (true) {
                try {
                    messages = db.messages(conversationId)
                    db.markConversationRead(conversationId)
                    error = null
                } catch (e: Exception) { error = e.message }
                delay(5000)
            }
        } catch (e: Exception) { error = e.message }
    }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) scroll.animateScrollToItem(messages.lastIndex)
    }

    AppPage {
        Column(Modifier.fillMaxSize().imePadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(top = Dimens.md, start = Dimens.sm, end = Dimens.regular),
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    // TODO: Заменить на кастомную SVG
                    Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                }
                Row(Modifier.weight(1f).clickable { if(otherId.isNotBlank()) onUser(otherId) },
                    verticalAlignment=Alignment.CenterVertically,
                    horizontalArrangement=Arrangement.spacedBy(Dimens.sm)) {
                    if(!otherAvatar.isNullOrBlank()) RemoteImage(db.publicImageUrl("avatars",otherAvatar!!),
                        Modifier.size(42.dp).clip(CircleShape),"Аватар собеседника")
                    else Box(Modifier.size(42.dp).background(MaterialTheme.colorScheme.surfaceVariant,CircleShape),
                        contentAlignment=Alignment.Center) {Text(header.take(1).uppercase())}
                    Column {
                    Text(header, style = MaterialTheme.typography.titleLarge)
                    Text(title, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            HorizontalDivider()
            if (error != null) Text("Ошибка: $error", modifier = Modifier.padding(Dimens.sm),
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            LazyColumn(Modifier.weight(1f), state = scroll,
                contentPadding = PaddingValues(Dimens.regular),
                verticalArrangement = Arrangement.spacedBy(Dimens.sm)) {
                items(messages, key = { it.id }) { message ->
                    val mine = message.senderId == myId && message.kind != "application"
                    Column(Modifier.fillMaxWidth(),
                        horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                        Box(Modifier.fillMaxWidth(.88f).background(
                            if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(Dimens.md)).padding(Dimens.md)) {
                            Column(verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
                                if (message.kind == "application") {
                                    Text("Новый отклик", style = MaterialTheme.typography.titleSmall)
                                }
                                Text(message.body, style = MaterialTheme.typography.bodyMedium,
                                    textAlign = TextAlign.Start)
                            }
                        }
                    }
                }
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth().padding(Dimens.sm), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(Dimens.xs)) {
                OutlinedTextField(value = input, onValueChange = { input = it.take(4000) },
                    modifier = Modifier.weight(1f), placeholder = { Text("Сообщение на русском или любом другом языке...") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Text),
                    maxLines = 4, shape = RoundedCornerShape(Dimens.md))
                IconButton(enabled = !sending && input.isNotBlank(), onClick = {
                    val sendingText = input
                    scope.launch {
                        sending = true
                        try {
                            db.sendMessage(conversationId, sendingText)
                            input = ""
                            messages = db.messages(conversationId)
                            db.markConversationRead(conversationId)
                            error = null
                        } catch (e: Exception) { error = e.message }
                        finally { sending = false }
                    }
                }) {
                    // TODO: Заменить на кастомную SVG
                    Icon(Icons.Default.Send, contentDescription = "Отправить",
                        tint = if (!sending && input.isNotBlank()) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
