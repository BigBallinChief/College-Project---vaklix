package ru.vakliks.app.ui.screens

import androidx.compose.runtime.Composable
import ru.vakliks.app.ui.components.JobFormScaffold

@Composable
fun EditVacancyScreen(onDone: () -> Unit, onDelete: () -> Unit, onFavorites: () -> Unit) {
    JobFormScaffold(isEdit = true, onDone = onDone, onDelete = onDelete, onFavorites = onFavorites)
}
