package ru.vakliks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun EmployerApplicationsScreen(vacancyId: String, onBack: () -> Unit, onChat: (String) -> Unit, onUser: (String) -> Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope = rememberCoroutineScope()
    var applications by remember { mutableStateOf<List<SupabaseDatabase.EmployerApplication>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var reviewTarget by remember { mutableStateOf<SupabaseDatabase.EmployerApplication?>(null) }
    var finishTarget by remember { mutableStateOf<SupabaseDatabase.EmployerApplication?>(null) }
    var archived by remember { mutableStateOf(false) }
    var stars by remember { mutableIntStateOf(5) }
    var comment by remember { mutableStateOf("") }
    var reviewing by remember { mutableStateOf(false) }
    var reviewedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    if(finishTarget!=null) AlertDialog(onDismissRequest={finishTarget=null},
        title={Text("Подтвердить завершение работы?")},
        text={Text("Статус станет «Завершено». После этого вы сможете оставить отзыв о сотруднике. Отменить завершение нельзя.")},
        confirmButton={TextButton(onClick={
            val target=finishTarget ?: return@TextButton
            finishTarget=null
            scope.launch {try {db.setApplicationStatus(target.id,"completed")
                applications=db.vacancyApplications(vacancyId);error=null
            }catch(e:Exception){error=e.message}}
        }){Text("Завершить")}},dismissButton={TextButton(onClick={finishTarget=null}){Text("Отмена")}})
    if(reviewTarget!=null) AlertDialog(onDismissRequest={reviewTarget=null},
        title={Text("Отзыв о выполненной работе")},
        text={Column(verticalArrangement=Arrangement.spacedBy(Dimens.sm)) {
            Text("Оценка: $stars из 5")
            Slider(stars.toFloat(),{stars=it.toInt().coerceIn(1,5)},valueRange=1f..5f,steps=3)
            OutlinedTextField(comment,{comment=it.take(2000)},label={Text("Отзыв о сотруднике")})
        }}, confirmButton={TextButton(enabled=!reviewing && comment.isNotBlank(),onClick={
            val target=reviewTarget ?: return@TextButton
            scope.launch {reviewing=true;try {
                db.addWorkerReview(target.id,target.applicantId,stars,comment)
                reviewedIds=reviewedIds+target.id;reviewTarget=null;comment="";error=null
            } catch(e:Exception){error=e.message} finally {reviewing=false}}
        }){Text("Опубликовать")}},dismissButton={TextButton(onClick={reviewTarget=null}){Text("Отмена")}})

    LaunchedEffect(vacancyId) {
        try { applications = db.vacancyApplications(vacancyId) }
        catch (e: Exception) { error = e.message }
    }
    AppPage {
        LazyColumn(contentPadding = PaddingValues(top = Dimens.toolbarTop, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(Dimens.md)) {
            item { Text("Отклики на вакансию", Modifier.padding(horizontal = Dimens.regular),
                style = MaterialTheme.typography.titleLarge) }
            if (error != null) item { Text("Ошибка: $error", Modifier.padding(horizontal = Dimens.regular),
                color = MaterialTheme.colorScheme.error) }
            if (applications.isEmpty()) item { Text("Откликов пока нет", Modifier.padding(horizontal = Dimens.regular)) }
            items(applications, key = { it.id }) { a ->
                Column(Modifier.fillMaxWidth().padding(horizontal = Dimens.regular)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(Dimens.sm))
                    .padding(Dimens.md), verticalArrangement = Arrangement.spacedBy(Dimens.sm)) {
                    Text(a.applicantName, Modifier.clickable { onUser(a.applicantId) },
                        style = MaterialTheme.typography.titleMedium,color=MaterialTheme.colorScheme.primary)
                    Text("Открыть профиль и отзывы",Modifier.clickable{onUser(a.applicantId)},
                        style=MaterialTheme.typography.bodySmall)
                    Text("Статус: ${when(a.status){
                        "pending"->"Ожидает";"reviewed"->"Просмотрено";
                        "accepted"->"Принят";"rejected"->"Отклонён";
                        "completed"->"Завершено";else->a.status
                    }}", style = MaterialTheme.typography.bodyMedium)
                    a.resume?.let { resume ->
                        if (resume.title.isNotBlank()) Text("Резюме: ${resume.title}")
                        if (resume.about.isNotBlank()) Text(resume.about, style = MaterialTheme.typography.bodySmall)
                        if (resume.skills.isNotBlank()) Text("Навыки: ${resume.skills}", style = MaterialTheme.typography.bodySmall)
                        if (resume.experience.isNotBlank()) Text("Опыт: ${resume.experience}", style = MaterialTheme.typography.bodySmall)
                    }
                    a.conversationId?.let { chatId ->
                        PrimaryButton("Написать соискателю", { onChat(chatId) }, Modifier.fillMaxWidth(), compact = true)
                    }
                    if(a.status == "accepted") {
                        PrimaryButton("Работа выполнена · завершить сделку",{
                            finishTarget=a
                        },Modifier.fillMaxWidth(),compact=true)
                    }
                    if(a.status == "completed") {
                        Text("Завершено",color=MaterialTheme.colorScheme.primary,
                            style=MaterialTheme.typography.titleMedium)
                        if(a.id !in reviewedIds) TextButton(onClick={
                            scope.launch {try {
                                if(db.hasWorkerReview(a.id)) reviewedIds=reviewedIds+a.id
                                else {comment="";stars=5;reviewTarget=a}
                            }catch(e:Exception){error=e.message}}
                        }){Text("Оставить отзыв о сотруднике")}
                        else Text("Отзыв опубликован",style=MaterialTheme.typography.bodySmall)
                    }
                    if(a.status != "completed") Row(horizontalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
                        listOf("reviewed" to "Просмотрено", "accepted" to "Принять", "rejected" to "Отклонить")
                            .forEach { (status,label) ->
                                TextButton(onClick = {
                                    scope.launch {
                                        try {
                                            db.setApplicationStatus(a.id,status)
                                            applications = db.vacancyApplications(vacancyId)
                                        } catch (e:Exception) { error = e.message }
                                    }
                                }) { Text(label, color = MaterialTheme.colorScheme.onSurface) }
                            }
                    }
                }
            }
            if(applications.any { it.status=="accepted" || it.status=="completed" }) item {
                Column(Modifier.fillMaxWidth().padding(horizontal=Dimens.regular),
                    verticalArrangement=Arrangement.spacedBy(Dimens.xxs)) {
                    Text("Если сотрудник найден, можно снять вакансию с публикации. " +
                        "Переписка и завершённые отклики сохранятся.",
                        style=MaterialTheme.typography.bodySmall)
                    TextButton(enabled=!archived,onClick={scope.launch {try {
                        db.archiveVacancy(vacancyId);archived=true;error=null
                    }catch(e:Exception){error=e.message}}}) {
                        Text(if(archived)"Вакансия снята с публикации" else "Закрыть вакансию для новых откликов")
                    }
                }
            }
            item { LinkButton("Назад", onBack) }
        }
    }
}
