package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ru.vakliks.app.R
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun EmptyFavoritesScreen(onNavigate: (String) -> Unit, onAll: () -> Unit) {
    var query by remember { mutableStateOf("") }
    AppPage(currentTab = "favorites", onNavigate = onNavigate) {
        Column(Modifier.fillMaxSize().padding(top = Dimens.toolbarTop)) {
            Column(Modifier.padding(horizontal = Dimens.regular), verticalArrangement = Arrangement.spacedBy(Dimens.sm)) {
                Greeting()
                SearchHeader(query, { query = it }, onFavorites = onAll, onFilters = { onNavigate("filters") })
                Spacer(Modifier.height(Dimens.regular))
                Text("Сохранено 0 вакансий", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onBackground)
                SortingRow()
            }
            Spacer(Modifier.weight(1f))
            MascotArtwork(R.drawable.mascot_empty, Modifier.fillMaxWidth().height(285.dp).padding(horizontal = Dimens.xxl), fadeBottom = true)
            Text("Похоже пусто", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center)
            Spacer(Modifier.height(Dimens.xs))
            Text("У вас нет избранных вакансий", modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1.15f))
        }
    }
}
