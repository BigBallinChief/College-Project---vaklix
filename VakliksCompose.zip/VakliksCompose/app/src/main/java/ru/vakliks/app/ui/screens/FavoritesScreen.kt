package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.vakliks.app.data.Vacancy
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun FavoritesScreen(onNavigate:(String)->Unit,onOpen:(String)->Unit,onEmpty:()->Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope=rememberCoroutineScope()
    var all by remember{mutableStateOf<List<Vacancy>>(emptyList())}
    var starred by remember{mutableStateOf<Set<String>>(emptySet())}
    var error by remember{mutableStateOf<String?>(null)}
    var query by remember{mutableStateOf("")}
    LaunchedEffect(Unit){try{starred=db.favorites();all=db.vacancies()}catch(e:Exception){error=e.message}}
    val displayed=all.filter{it.id in starred&&(query.isBlank()||it.title.contains(query,true))}
    AppPage(currentTab="favorites",onNavigate=onNavigate) {
        LazyColumn(contentPadding=PaddingValues(top=Dimens.toolbarTop,bottom=105.dp),verticalArrangement=Arrangement.spacedBy(Dimens.xs)){
            item{Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.sm)){
                Greeting()
                SearchHeader(query,{query=it},onFavorites=onEmpty,onFilters={onNavigate("filters")})
                Spacer(Modifier.height(Dimens.regular))
                Text("Сохранено ${displayed.size} вакансий",style=MaterialTheme.typography.titleSmall)
                SortingRow()
                if(error!=null)Text("Ошибка: $error",color=MaterialTheme.colorScheme.error)
                else if(displayed.isEmpty())Text("В избранном пока пусто",style=MaterialTheme.typography.bodyMedium)
            }}
            items(displayed,key={it.id}){v->VacancyCard(v,modifier=Modifier.padding(horizontal=Dimens.regular).fillMaxWidth().heightIn(min=174.dp),
                isFavorite=true,onOpen={onOpen(v.id)},onFavorite={scope.launch{try{db.setFavorite(v.id,false);starred=starred-v.id}catch(e:Exception){error=e.message}}},onApply={onOpen(v.id)})}
        }
    }
}
