package ru.vakliks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import ru.vakliks.app.data.VacancyFilters
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
private fun ChoiceSection(title:String,options:List<Pair<String,String>>,selected:String,onSelect:(String)->Unit){
    Column(verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
        Text(title,style=MaterialTheme.typography.titleSmall)
        options.chunked(3).forEach{group->Row(horizontalArrangement=Arrangement.spacedBy(Dimens.xxs)) {
            group.forEach{(label,value)->FilterChip(label,selected=selected==value,onClick={onSelect(if(selected==value)"" else value)})}
        }}
    }
}

@Composable
fun FiltersScreen(initial:VacancyFilters=VacancyFilters(),onApply:(VacancyFilters)->Unit,onFavorites:()->Unit){
    var query by remember{mutableStateOf(initial.query)}
    var city by remember{mutableStateOf(initial.city)}
    var schedule by remember{mutableStateOf(initial.schedule)}
    var experience by remember{mutableStateOf(initial.experience)}
    var format by remember{mutableStateOf(initial.workFormat)}
    var employment by remember{mutableStateOf(initial.employment)}
    var specialization by remember{mutableStateOf(initial.specialization)}
    var salary by remember{mutableStateOf(initial.minSalary?.toString().orEmpty())}
    var period by remember{mutableStateOf(initial.period)}
    AppPage{
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.regular)){
            Spacer(Modifier.height(Dimens.toolbarTop))
            CatalogTopBar(query,onSearch={query=it},onFavorites=onFavorites,onFilters={},isFilters=true,showGreeting=false)
            Column(verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                Text("Регион",style=MaterialTheme.typography.titleSmall)
                AppTextField(city,{city=it},"Любой город")
            }
            ChoiceSection("График работы",listOf("5/2" to "5/2","2/2" to "2/2","6/1" to "6/1","3/3" to "3/3"),schedule,{schedule=it})
            ChoiceSection("Опыт работы",listOf("Нет опыта" to "Нет опыта","1–3 года" to "1–3 года","3–6 лет" to "3–6 лет","Более 6 лет" to "6+ лет"),experience,{experience=it})
            ChoiceSection("Формат работы",listOf("На месте" to "На месте работодателя","Удалённо" to "Удалённо","Гибрид" to "Гибрид"),format,{format=it})
            ChoiceSection("Тип занятости",listOf("Полная" to "Полная занятость","Частичная" to "Частичная занятость","Подработка" to "Подработка"),employment,{employment=it})
            Column(verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                Text("Зарплата от",style=MaterialTheme.typography.titleSmall)
                AppTextField(salary,{salary=it.filter(Char::isDigit)},"Укажите сумму, ₽")
            }
            ChoiceSection("Период зарплаты",listOf("За месяц" to "month","За смену" to "shift","За час" to "hour","За услугу" to "service"),period,{period=it})
            Column(verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                Text("Специализация",style=MaterialTheme.typography.titleSmall)
                AppTextField(specialization,{specialization=it},"Например, курьер")
            }
            Spacer(Modifier.height(Dimens.toolbarTop))
        }
        Row(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal=Dimens.regular,vertical=Dimens.sm)
            .fillMaxWidth().background(MaterialTheme.colorScheme.surface,RoundedCornerShape(Dimens.inputRadius)).padding(Dimens.xxs),
            verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(Dimens.xxs)){
            Box(Modifier.weight(1f)){LinkButton("Сбросить",{query="";city="";schedule="";experience="";format="";employment="";specialization="";salary="";period=""})}
            PrimaryButton("Применить фильтры",{
                onApply(VacancyFilters(query,city,schedule,experience,format,employment,salary.toLongOrNull(),specialization,period))
            },modifier=Modifier.weight(1.35f),compact=true)
        }
    }
}
