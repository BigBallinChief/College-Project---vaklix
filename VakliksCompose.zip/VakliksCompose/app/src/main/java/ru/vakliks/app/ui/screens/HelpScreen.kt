package ru.vakliks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.provider.Settings
import androidx.compose.ui.unit.dp
import ru.vakliks.app.ui.components.AppPage
import ru.vakliks.app.ui.theme.Dimens

/** FAQ describes only features actually present in the Android app. */
@Composable
fun HelpScreen(onBack:()->Unit) {
    val context = LocalContext.current
    val topics = listOf(
        "Как зарегистрироваться?" to "На стартовом экране выберите «Создать аккаунт», укажите имя, email и пароль. Если Supabase запросит подтверждение адреса, перейдите по ссылке из письма. Затем войдите с email и паролем.",
        "Как найти вакансию?" to "Откройте главную или вкладку поиска. Используйте строку поиска по профессии, а для условий работы нажмите значок фильтра справа от поиска. Откройте карточку для подробного описания и фотографий.",
        "Как откликнуться?" to "Откройте опубликованную вакансию и нажмите «Откликнуться». Появится диалог с работодателем; он увидит ваши данные и заполненное резюме. Один аккаунт может отправить только один отклик на одну вакансию.",
        "Где изменить резюме?" to "Откройте вкладку профиля → «Моё резюме». Заполните опыт, навыки и город, затем сохраните. Эти данные будут переданы работодателю в диалоге отклика.",
        "Как написать работодателю?" to "Нажмите «Сообщения» на нижней панели. Диалог появляется после отклика. Откройте его и отправьте текст. Можно писать по-русски; при необходимости добавьте русский язык в настройках клавиатуры телефона.",
        "Почему клавиатура только на английском?" to "В приложении ввод кириллицы разрешён. Язык экранной клавиатуры задаётся Android/Gboard. Откройте настройки клавиатуры → Языки → Добавить клавиатуру → Русский. В поле ввода переключайте язык значком глобуса или удержанием пробела. Ниже есть кнопка перехода к настройкам клавиатуры.",
        "Как разместить вакансию?" to "В профиле откройте «Моя организация», создайте организацию и нажмите «Добавить вакансию». Заполните название, город, условия и добавьте до пяти фотографий. Сохраните вакансию для публикации.",
        "Как поменять фото вакансии?" to "В своей организации откройте редактирование вакансии. Нажмите на старую фотографию, чтобы убрать её из выбранного слота, затем добавьте новую. Не забудьте сохранить изменения.",
        "Как посмотреть отклики?" to "В профиле организации у своей вакансии нажмите «Просмотреть отклики». Там доступны имя соискателя, резюме, переход в профиль и переписка.",
        "Как завершить работу и оставить отзыв?" to "Работодатель принимает отклик, затем после выполнения работы нажимает «Работа выполнена · завершить сделку». Появится статус «Завершено» и возможность оценить сотрудника. Опубликованный отзыв будет виден в его профиле.",
        "Как посмотреть отзывы?" to "Откройте профиль автора вакансии или собеседника. Отзывы о выполненной работе показаны в его профиле; в блоке компаний можно открыть компанию и прочитать отзывы о ней.",
        "Как выйти из аккаунта?" to "Откройте профиль и нажмите «Выйти из аккаунта». Для входа снова потребуется email и пароль."
    )
    AppPage {
        LazyColumn(contentPadding=PaddingValues(start=Dimens.regular,end=Dimens.regular,
            top=Dimens.toolbarTop,bottom=95.dp),verticalArrangement=Arrangement.spacedBy(Dimens.sm)) {
            item {Row {IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Назад")}
                Text("Помощь и поддержка",style=MaterialTheme.typography.titleLarge,
                    modifier=Modifier.padding(top=12.dp))}}
            item {Text("Частые вопросы по Vakclix",style=MaterialTheme.typography.bodyMedium)}
            item {
                OutlinedButton(onClick = {
                    val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                    runCatching { context.startActivity(intent) }
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("Настроить русскую клавиатуру")
                }
            }
            items(topics.size) { index ->
                val (question,answer)=topics[index]
                Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface,
                    RoundedCornerShape(Dimens.sm)).padding(Dimens.md),
                    verticalArrangement=Arrangement.spacedBy(Dimens.xxs)) {
                    Text(question,style=MaterialTheme.typography.titleMedium)
                    Text(answer,style=MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
