package ru.vakliks.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlinx.coroutines.launch
import ru.vakliks.app.R
import ru.vakliks.app.data.Vacancy
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun HomeScreen(onNavigate:(String)->Unit,onVacancy:(String)->Unit,onCompany:(String)->Unit,onAll:()->Unit,onResume:()->Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope=rememberCoroutineScope()
    var jobs by remember { mutableStateOf<List<Vacancy>>(emptyList()) }
    var favorites by remember { mutableStateOf<Set<String>>(emptySet()) }
    var error by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        try { jobs=db.vacancies(); favorites=runCatching{db.favorites()}.getOrDefault(emptySet()) }
        catch(e:Exception){error=e.message}
        finally { isLoading = false }
    }
    fun toggle(id:String) { scope.launch { try {db.setFavorite(id,id !in favorites); favorites=if(id in favorites) favorites-id else favorites+id} catch(e:Exception){error=e.message} } }
    AppPage(currentTab="home",onNavigate=onNavigate) {
        LazyColumn(contentPadding=PaddingValues(top=Dimens.toolbarTop,bottom=105.dp),verticalArrangement=Arrangement.spacedBy(Dimens.regular)) {
            item { Column(verticalArrangement=Arrangement.spacedBy(Dimens.xs)) {
                Greeting()
                Row(Modifier.padding(horizontal=Dimens.regular)){SearchHeader(query,{query=it;if(it.isNotBlank())onAll()},onFavorites={onNavigate("favorites")},onFilters={onNavigate("filters")})}
            } }
            item { Box(Modifier.padding(horizontal=Dimens.regular).fillMaxWidth().height(160.dp).background(MaterialTheme.colorScheme.primary,RoundedCornerShape(Dimens.regular))) {
                Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(.69f).padding(Dimens.md),verticalArrangement=Arrangement.spacedBy(Dimens.xs)) {
                    Text("Найдите работу мечты",style=MaterialTheme.typography.headlineSmall,color=MaterialTheme.colorScheme.onPrimary)
                    Text("Заполните резюме, чтобы работодатели могли вас найти",style=MaterialTheme.typography.bodyLarge,color=MaterialTheme.colorScheme.onPrimary)
                    MutedButton("Создать резюме",onResume)
                }
                Image(painterResource(R.drawable.mascot_phone),null,Modifier.align(Alignment.BottomEnd).width(165.dp).height(165.dp),contentScale=ContentScale.Crop)
            } }
            item { SectionHeading("Для вас","Показать все",onAll) }
            item { if(isLoading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal=Dimens.regular))
                if(error!=null) Text("Ошибка загрузки: $error",Modifier.padding(Dimens.regular),color=MaterialTheme.colorScheme.error)
                else if(jobs.isEmpty()) Text("Пока нет опубликованных вакансий",Modifier.padding(Dimens.regular),style=MaterialTheme.typography.bodyMedium)
                else Row(Modifier.fillMaxWidth().padding(horizontal=Dimens.regular),horizontalArrangement=Arrangement.spacedBy(Dimens.sm)) {
                    jobs.take(2).forEach { v -> VacancyCard(v,true,v.id in favorites,{onVacancy(v.id)},{toggle(v.id)},{onVacancy(v.id)},{onCompany(v.organizationId)},Modifier.weight(1f).height(245.dp)) }
                }
            }
            item { SectionHeading("Новые вакансии","Показать все",onAll) }
            item { Row(Modifier.fillMaxWidth().padding(horizontal=Dimens.regular),horizontalArrangement=Arrangement.spacedBy(Dimens.sm)) {
                jobs.take(2).forEach { v -> VacancyCard(v,true,v.id in favorites,{onVacancy(v.id)},{toggle(v.id)},{onVacancy(v.id)},{onCompany(v.organizationId)},Modifier.weight(1f).height(245.dp)) }
            } }
        }
    }
}
