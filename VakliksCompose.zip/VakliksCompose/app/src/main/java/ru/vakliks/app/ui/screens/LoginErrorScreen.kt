package ru.vakliks.app.ui.screens

import androidx.compose.runtime.Composable
import ru.vakliks.app.ui.components.AuthLayout

@Composable
fun LoginErrorScreen(onLogin: () -> Unit, onRegister: () -> Unit) {
    AuthLayout(false, true, onSubmit = { _, _, _ -> onLogin() }, onSwitch = onRegister, onForgot = { onLogin() })
}
