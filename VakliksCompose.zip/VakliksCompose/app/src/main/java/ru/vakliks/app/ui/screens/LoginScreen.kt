package ru.vakliks.app.ui.screens

import androidx.compose.runtime.Composable
import ru.vakliks.app.ui.components.AuthLayout

@Composable
fun LoginScreen(
    onLogin: (String, String) -> Unit,
    onRegister: () -> Unit,
    onForgotPassword: (String) -> Unit,
    isLoading: Boolean,
    errorMessage: String?,
) {
    AuthLayout(isRegistration = false, isError = false, onSubmit = { email, password, _ -> onLogin(email, password) },
        onSwitch = onRegister, onForgot = onForgotPassword,
        isSubmitting = isLoading, serverError = errorMessage)
}
