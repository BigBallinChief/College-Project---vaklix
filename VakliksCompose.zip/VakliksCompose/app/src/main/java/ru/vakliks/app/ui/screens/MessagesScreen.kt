package ru.vakliks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.AppPage
import ru.vakliks.app.ui.components.RemoteImage
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun MessagesScreen(onNavigate: (String) -> Unit, onOpen: (String) -> Unit, onUser: (String) -> Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    var conversations by remember { mutableStateOf<List<SupabaseDatabase.ChatThread>>(emptyList()) }
    var busy by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            try { conversations = db.conversations(); error = null }
            catch (e: Exception) { error = e.message }
            finally { busy = false }
            delay(12000)
        }
    }
    AppPage(currentTab = "messages", onNavigate = onNavigate) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = Dimens.regular, end = Dimens.regular,
                top = Dimens.toolbarTop, bottom = 115.dp),
            verticalArrangement = Arrangement.spacedBy(Dimens.sm)
        ) {
            item { Text("Сообщения", style = MaterialTheme.typography.headlineSmall) }
            if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            if (error != null) item { Text("Ошибка: $error", color = MaterialTheme.colorScheme.error) }
            if (!busy && conversations.isEmpty() && error == null) {
                item { Column(Modifier.fillMaxWidth().padding(top = 90.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    // TODO: Заменить на кастомную SVG
                    Icon(Icons.Default.ChatBubbleOutline, null, Modifier.size(54.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(Dimens.md))
                    Text("Пока нет сообщений", style = MaterialTheme.typography.titleMedium)
                    Text("Когда вы откликнетесь на вакансию, здесь появится переписка.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                } }
            }
            items(conversations, key = { it.id }) { chat ->
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(Dimens.sm))
                        .clickable { onOpen(chat.id) }.padding(Dimens.md),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(Dimens.sm)
                ) {
                    // TODO: Заменить на кастомную SVG
                    val avatar = remember(chat.otherUserId) { mutableStateOf<String?>(null) }
                    LaunchedEffect(chat.otherUserId) {
                        avatar.value = runCatching { db.publicProfile(chat.otherUserId)?.avatarPath }.getOrNull()
                    }
                    if(!avatar.value.isNullOrBlank()) RemoteImage(db.publicImageUrl("avatars",avatar.value!!),
                        Modifier.size(46.dp).clip(CircleShape)
                            .clickable { onUser(chat.otherUserId) },"Аватар")
                    else Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.surfaceVariant,CircleShape)
                        .clickable{onUser(chat.otherUserId)},
                        contentAlignment=Alignment.Center) {Text(chat.otherName.take(1).uppercase())}
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
                        Text(chat.otherName, style = MaterialTheme.typography.titleMedium)
                        Text(chat.title, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        Text(chat.latestText.ifBlank { "Откройте переписку" },
                            style = MaterialTheme.typography.bodySmall, maxLines = 2,
                            overflow = TextOverflow.Ellipsis)
                    }
                    if (chat.unread > 0) {
                        Box(Modifier.background(MaterialTheme.colorScheme.primary, RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                            Text("${chat.unread}", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, "Открыть", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
