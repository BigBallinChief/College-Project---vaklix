package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun MyApplicationsScreen(onNavigate:(String)->Unit,onOpen:(String)->Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    var applications by remember{mutableStateOf<List<SupabaseDatabase.Application>>(emptyList())}
    var error by remember{mutableStateOf<String?>(null)}
    LaunchedEffect(Unit){try{applications=db.myApplications()}catch(e:Exception){error=e.message}}
    AppPage(currentTab="profile",onNavigate=onNavigate){
        LazyColumn(contentPadding=PaddingValues(top=Dimens.toolbarTop,bottom=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.md)){
            item{Text("Мои отклики",Modifier.padding(horizontal=Dimens.regular),style=MaterialTheme.typography.titleLarge)}
            if(error!=null)item{Text("Ошибка: $error",Modifier.padding(horizontal=Dimens.regular),color=MaterialTheme.colorScheme.error)}
            else if(applications.isEmpty())item{Text("Откликов пока нет",Modifier.padding(horizontal=Dimens.regular))}
            items(applications,key={it.id}){a->Column(Modifier.fillMaxWidth().padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                Text(a.title.ifBlank { "Вакансия" },style=MaterialTheme.typography.titleMedium)
                Text("Статус: ${when(a.status){"pending"->"На рассмотрении";"reviewed"->"Просмотрено";"accepted"->"Принято";"rejected"->"Отклонено";else->a.status}}")
                LinkButton("Открыть вакансию",{onOpen(a.vacancyId)})
                a.conversationId?.let { conversation -> LinkButton("Открыть переписку", { onNavigate("chat/$conversation") }) }
            }}
        }
    }
}
