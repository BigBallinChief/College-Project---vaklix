package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ru.vakliks.app.R
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun NoResultsScreen(onNavigate: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    AppPage(currentTab = "jobs", onNavigate = onNavigate) {
        Column(Modifier.fillMaxSize().padding(top = Dimens.toolbarTop)) {
            Column(Modifier.padding(horizontal = Dimens.regular), verticalArrangement = Arrangement.spacedBy(Dimens.xs)) {
                Greeting()
                SearchHeader(query, { query = it }, onFavorites = { onNavigate("favorites") }, onFilters = { onNavigate("filters") })
                QuickSearchChips(onSelect = { onNavigate("filters") })
                Spacer(Modifier.height(28.dp))
                Text("Найдено 0 вакансий", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onBackground)
                SortingRow()
            }
            Spacer(Modifier.weight(1f))
            MascotArtwork(R.drawable.mascot_empty, Modifier.fillMaxWidth().height(285.dp).padding(horizontal = Dimens.xxl), fadeBottom = true)
            Text("Похоже пусто", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center)
            Spacer(Modifier.height(Dimens.xs))
            Text("По вашим фильтрам ничего не было найдено", modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1.1f))
        }
    }
}
