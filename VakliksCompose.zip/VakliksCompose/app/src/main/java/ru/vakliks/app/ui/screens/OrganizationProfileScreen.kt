package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.vakliks.app.data.Vacancy
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun OrganizationProfileScreen(organizationId:String?,onNavigate:(String)->Unit,onEdit:(String)->Unit,onAdd:(String)->Unit,onOpen:(String)->Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope=rememberCoroutineScope()
    var organization by remember(organizationId){mutableStateOf<SupabaseDatabase.Organization?>(null)}
    var myOrgs by remember{mutableStateOf<List<SupabaseDatabase.Organization>>(emptyList())}
    var jobs by remember{mutableStateOf<List<Vacancy>>(emptyList())}
    var error by remember{mutableStateOf<String?>(null)}
    var createDialog by remember{mutableStateOf(false)}
    var name by remember{mutableStateOf("")}
    var city by remember{mutableStateOf("")}
    var busy by remember{mutableStateOf(false)}
    var reviews by remember{mutableStateOf<List<SupabaseDatabase.Review>>(emptyList())}
    var reviewDialog by remember{mutableStateOf(false)}
    var reviewText by remember{mutableStateOf("")}
    var reviewStars by remember{mutableIntStateOf(5)}
    val logoPicker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val org=organization
        if(uri!=null&&org!=null)scope.launch{try{
            val path=db.uploadPhoto(context,uri,"organization-logos",org.id)
            db.updateOrganizationLogo(org.id,path)
            organization=db.organization(org.id)
        }catch(e:Exception){error=e.message}}
    }
    suspend fun refresh(){
        myOrgs=runCatching{db.organizationsMine()}.getOrDefault(emptyList())
        organization=if(organizationId!=null)db.organization(organizationId) else myOrgs.firstOrNull()
        jobs=organization?.let{db.myVacancies(it.id)} ?: emptyList()
        reviews=organization?.let{db.reviews(it.id)} ?: emptyList()
    }
    LaunchedEffect(organizationId){try{refresh()}catch(e:Exception){error=e.message}}
    val canEdit=organization!=null && myOrgs.any{it.id==organization?.id}
    if(createDialog)AlertDialog(onDismissRequest={createDialog=false},title={Text("Новая организация")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        OutlinedTextField(name,{name=it},label={Text("Название компании")},singleLine=true)
        OutlinedTextField(city,{city=it},label={Text("Город")},singleLine=true)
        if(error!=null)Text(error!!,color=MaterialTheme.colorScheme.error)
    }},confirmButton={TextButton(enabled=!busy&&name.isNotBlank(),onClick={scope.launch{
        busy=true;try{db.createOrganization(name,city);createDialog=false;refresh()}catch(e:Exception){error=e.message}finally{busy=false}
    }}){Text("Создать")}},dismissButton={TextButton(onClick={createDialog=false}){Text("Отмена")}})
    if(reviewDialog)AlertDialog(onDismissRequest={reviewDialog=false},title={Text("Оставить отзыв")},text={Column {
        Text("Оценка: $reviewStars из 5")
        Slider(reviewStars.toFloat(),{reviewStars=it.toInt().coerceIn(1,5)},valueRange=1f..5f,steps=3)
        OutlinedTextField(reviewText,{reviewText=it},label={Text("Отзыв")})
    }},confirmButton={TextButton(onClick={scope.launch{try{
        organization?.let{db.addReview(it.id,reviewStars,reviewText);reviews=db.reviews(it.id)}
        reviewDialog=false
    }catch(e:Exception){error=e.message}}}){Text("Отправить")}},dismissButton={TextButton(onClick={reviewDialog=false}){Text("Отмена")}})
    AppPage(currentTab="profile",onNavigate=onNavigate){
        LazyColumn(contentPadding=PaddingValues(top=Dimens.toolbarTop,bottom=110.dp),verticalArrangement=Arrangement.spacedBy(Dimens.regular)){
            item{Text("Профиль организации",Modifier.padding(horizontal=Dimens.regular),style=MaterialTheme.typography.titleLarge)}
            item{Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.sm)){
                if(organization==null){
                    Text("У вас пока нет организации. Создайте её, чтобы публиковать вакансии.")
                }else{
                    RemoteImage(organization?.logoPath?.let{db.publicImageUrl("organization-logos",it)},Modifier.size(112.dp),"Логотип")
                    Text(organization!!.name,style=MaterialTheme.typography.titleLarge)
                    Text("Рейтинг: ${if(reviews.isEmpty())"—" else "%.1f".format(reviews.map{it.rating}.average())} · отзывов: ${reviews.size}")
                    if(canEdit) LinkButton("Загрузить логотип",{logoPicker.launch("image/*")})
                    else LinkButton("Оставить отзыв",{reviewDialog=true})
                    if(organization!!.city.isNotBlank())Text(organization!!.city)
                    if(organization!!.description.isNotBlank())Text(organization!!.description)
                }
                if(error!=null)Text("Ошибка: $error",color=MaterialTheme.colorScheme.error)
                if(organizationId==null)PrimaryButton("Создать организацию",{createDialog=true},Modifier.fillMaxWidth())
            }}
            if(canEdit){
                item{SectionHeading("Мои вакансии","Добавить",{onAdd(organization!!.id)})}
                items(jobs,key={it.id}){v->Column {
                    VacancyCard(v,modifier=Modifier.padding(horizontal=Dimens.regular).fillMaxWidth().heightIn(min=175.dp),
                        onOpen={onEdit(v.id)},onFavorite={onEdit(v.id)},onApply={onEdit(v.id)},onCompany={})
                    LinkButton("Просмотреть отклики",{onNavigate("employer_applications/${v.id}")},Modifier.padding(horizontal=Dimens.regular))
                }}
                item{PrimaryButton("Добавить вакансию",{onAdd(organization!!.id)},Modifier.padding(horizontal=Dimens.regular).fillMaxWidth())}
            }else if(organization!=null){
                item{SectionHeading("Вакансии компании","",{})}
                items(jobs.filter{it.status=="published"},key={it.id}){v->VacancyCard(v,modifier=Modifier.padding(horizontal=Dimens.regular).fillMaxWidth().heightIn(min=175.dp),onOpen={onOpen(v.id)},onFavorite={onOpen(v.id)},onApply={onOpen(v.id)})}
            }
            if(organization!=null){
                item{Text("Отзывы",Modifier.padding(horizontal=Dimens.regular),style=MaterialTheme.typography.titleLarge)}
                items(reviews,key={it.id}){r->Column(Modifier.padding(horizontal=Dimens.regular)){
                    Text("★ ${r.rating}/5",style=MaterialTheme.typography.titleMedium)
                    Text(r.comment.ifBlank{"Без комментария"},style=MaterialTheme.typography.bodyMedium)
                }}
            }
        }
    }
}
