package ru.vakliks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.AppPage
import ru.vakliks.app.ui.components.RemoteImage
import ru.vakliks.app.ui.components.ProfileMenuRow
import ru.vakliks.app.ui.theme.Dimens

/** Public profile: no phone, private CV, or other protected account fields. */
@Composable
fun PublicUserScreen(userId: String, onBack: () -> Unit, onOrganization: (String) -> Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    var profile by remember(userId) { mutableStateOf<SupabaseDatabase.Profile?>(null) }
    var companies by remember(userId) { mutableStateOf<List<SupabaseDatabase.Organization>>(emptyList()) }
    var workerReviews by remember(userId) { mutableStateOf<List<SupabaseDatabase.WorkerReview>>(emptyList()) }
    var companyReviewCounts by remember(userId) { mutableStateOf<Map<String,Int>>(emptyMap()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(userId) {
        loading=true
        try {
            profile=db.publicProfile(userId)
            companies=db.organizationsByOwner(userId)
            workerReviews=db.workerReviews(userId)
            companyReviewCounts=companies.associate { org -> org.id to db.reviews(org.id).size }
            error=null
        } catch(e:Exception){error=e.message}
        finally {loading=false}
    }
    AppPage {
        LazyColumn(modifier=Modifier.fillMaxSize(),
            contentPadding=PaddingValues(start=Dimens.regular,end=Dimens.regular,top=Dimens.toolbarTop,bottom=110.dp),
            verticalArrangement=Arrangement.spacedBy(Dimens.md)) {
            item {Row(verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=onBack) {Icon(Icons.Default.ArrowBack,"Назад")}
                Text("Профиль пользователя",style=MaterialTheme.typography.titleLarge)
            }}
            if(loading)item {LinearProgressIndicator(Modifier.fillMaxWidth())}
            if(error!=null)item {Text("Ошибка: $error",color=MaterialTheme.colorScheme.error)}
            profile?.let { user ->
                item {Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface,
                    RoundedCornerShape(Dimens.sm)).padding(Dimens.md),
                    verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(Dimens.md)) {
                    if(!user.avatarPath.isNullOrBlank()) RemoteImage(db.publicImageUrl("avatars",user.avatarPath),
                        Modifier.size(86.dp).clip(CircleShape),"Аватар пользователя")
                    else Box(Modifier.size(86.dp).background(MaterialTheme.colorScheme.surfaceVariant,CircleShape),
                        contentAlignment=Alignment.Center) {Text(user.fullName.take(1).uppercase(),style=MaterialTheme.typography.headlineLarge)}
                    Column {Text(user.fullName,style=MaterialTheme.typography.titleLarge)
                        if(user.city.isNotBlank()) Text(user.city,style=MaterialTheme.typography.bodyMedium)
                        Text("Отзывов о работе: ${workerReviews.size}",style=MaterialTheme.typography.bodySmall)
                    }
                }}
                item {Text("Отзывы о работе пользователя",style=MaterialTheme.typography.titleLarge)}
                if(workerReviews.isEmpty())item {Text("Отзывов о выполненной работе пока нет",style=MaterialTheme.typography.bodyMedium)}
                items(workerReviews,key={it.id}) {review ->
                    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface,RoundedCornerShape(Dimens.sm))
                        .padding(Dimens.md),verticalArrangement=Arrangement.spacedBy(Dimens.xxs)) {
                        Text("★ ${review.rating} из 5",style=MaterialTheme.typography.titleMedium)
                        Text(review.comment,style=MaterialTheme.typography.bodyMedium)
                    }
                }
                item {Text("Компании пользователя и отзывы",style=MaterialTheme.typography.titleLarge)}
                if(companies.isEmpty())item {Text("У пользователя пока нет компаний")}
                items(companies,key={it.id}) { org ->
                    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface,RoundedCornerShape(Dimens.sm))
                        .clickable{onOrganization(org.id)}.padding(Dimens.md),
                        verticalArrangement=Arrangement.spacedBy(Dimens.xxs)) {
                        Text(org.name,style=MaterialTheme.typography.titleMedium)
                        Text("Отзывов о компании: ${companyReviewCounts[org.id] ?: 0}",style=MaterialTheme.typography.bodyMedium)
                        Text("Открыть компанию и посмотреть отзывы",color=MaterialTheme.colorScheme.primary,
                            style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
