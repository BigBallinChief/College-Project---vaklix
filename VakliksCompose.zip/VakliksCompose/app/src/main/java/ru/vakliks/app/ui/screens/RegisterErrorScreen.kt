package ru.vakliks.app.ui.screens

import androidx.compose.runtime.Composable
import ru.vakliks.app.ui.components.AuthLayout

@Composable
fun RegisterErrorScreen(onVerify: () -> Unit, onLogin: () -> Unit) {
    AuthLayout(true, true, onSubmit = { _, _, _ -> onVerify() }, onSwitch = onLogin, onForgot = { onLogin() })
}
