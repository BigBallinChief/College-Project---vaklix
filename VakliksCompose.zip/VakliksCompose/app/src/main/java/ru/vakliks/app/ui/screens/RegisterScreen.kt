package ru.vakliks.app.ui.screens

import androidx.compose.runtime.Composable
import ru.vakliks.app.ui.components.AuthLayout

@Composable
fun RegisterScreen(
    onRegister: (String, String, String) -> Unit,
    onLogin: () -> Unit,
    isLoading: Boolean,
    errorMessage: String?,
) {
    AuthLayout(isRegistration = true, isError = false, onSubmit = onRegister,
        onSwitch = onLogin, onForgot = {}, isSubmitting = isLoading, serverError = errorMessage)
}
