package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.AppPage
import ru.vakliks.app.ui.components.PrimaryButton
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun ResumeScreen(onBack:()->Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope=rememberCoroutineScope()
    var id by remember{mutableStateOf<String?>(null)}
    var title by remember{mutableStateOf("")}
    var about by remember{mutableStateOf("")}
    var experience by remember{mutableStateOf("")}
    var skills by remember{mutableStateOf("")}
    var city by remember{mutableStateOf("")}
    var salary by remember{mutableStateOf("")}
    var error by remember{mutableStateOf<String?>(null)}
    var busy by remember{mutableStateOf(false)}
    LaunchedEffect(Unit){try{db.myResume()?.let{r->id=r.id;title=r.title;about=r.about;experience=r.experience;skills=r.skills;city=r.city;salary=r.desiredSalary?.toString().orEmpty()}}catch(e:Exception){error=e.message}}
    AppPage {Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=Dimens.regular,vertical=Dimens.toolbarTop),verticalArrangement=Arrangement.spacedBy(Dimens.sm)){
        Text("Моё резюме",style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(title,{title=it},label={Text("Должность")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(about,{about=it},label={Text("О себе")},modifier=Modifier.fillMaxWidth(),minLines=3)
        OutlinedTextField(experience,{experience=it},label={Text("Опыт работы")},modifier=Modifier.fillMaxWidth(),minLines=2)
        OutlinedTextField(skills,{skills=it},label={Text("Навыки")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(city,{city=it},label={Text("Город")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(salary,{salary=it.filter(Char::isDigit)},label={Text("Желаемая зарплата, ₽")},modifier=Modifier.fillMaxWidth())
        if(error!=null)Text(error!!,color=MaterialTheme.colorScheme.error)
        PrimaryButton(if(busy)"Сохраняем..." else "Сохранить резюме",{if(!busy)scope.launch{busy=true;try{db.saveResume(id,title,about,experience,skills,city,salary.toLongOrNull());onBack()}catch(e:Exception){error=e.message}finally{busy=false}}},Modifier.fillMaxWidth())
        Spacer(Modifier.height(80.dp))
    }}
}
