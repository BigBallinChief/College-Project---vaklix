package ru.vakliks.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens
import ru.vakliks.app.data.remote.SupabaseDatabase
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.launch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.RadioButton
import ru.vakliks.app.ui.theme.ThemePreference

@Composable
fun UserProfileScreen(onNavigate: (String) -> Unit, onResume: () -> Unit, onOrganization: () -> Unit, onLogout: () -> Unit, email: String?) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope = rememberCoroutineScope()
    var profile by remember { mutableStateOf<SupabaseDatabase.Profile?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var ownWorkReviews by remember { mutableStateOf<List<SupabaseDatabase.WorkerReview>>(emptyList()) }
    var ownedCompanies by remember { mutableStateOf<List<SupabaseDatabase.Organization>>(emptyList()) }
    var companyReviewCount by remember { mutableIntStateOf(0) }
    var editProfile by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    val pickAvatar = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if(uri != null)scope.launch { try {
            val id = db.currentUserId()
            val path = db.uploadPhoto(context,uri,"avatars",id)
            val pr = profile ?: db.profile()
            db.updateProfile(pr.fullName,pr.city,avatarPath=path)
            profile=db.profile()
        } catch(e:Exception) { error=e.message } }
    }
    LaunchedEffect(Unit) { try {
        profile=db.profile();name=profile?.fullName.orEmpty();city=profile?.city.orEmpty()
        val p=profile
        if(p!=null){
            ownWorkReviews=db.workerReviews(p.id)
            ownedCompanies=db.organizationsByOwner(p.id)
            companyReviewCount=ownedCompanies.sumOf { db.reviews(it.id).size }
        }
    }catch(e:Exception){error=e.message} }
    if (showThemeDialog) AlertDialog(
        onDismissRequest = { showThemeDialog = false },
        title = { Text("Тема приложения") },
        text = {
            Column {
                listOf("system" to "Как в системе", "light" to "Светлая", "dark" to "Тёмная").forEach { (value, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { ThemePreference.set(context, value); showThemeDialog = false },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = ThemePreference.mode == value,
                            onClick = { ThemePreference.set(context, value); showThemeDialog = false })
                        Text(label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showThemeDialog = false }) { Text("Закрыть") } }
    )
    if(editProfile)AlertDialog(onDismissRequest={editProfile=false},title={Text("Редактировать профиль")},text={Column {
        OutlinedTextField(name,{name=it},label={Text("Имя")})
        OutlinedTextField(city,{city=it},label={Text("Город")})
    }},confirmButton={TextButton(onClick={scope.launch{try{db.updateProfile(name,city);profile=db.profile();editProfile=false}catch(e:Exception){error=e.message}}}){Text("Сохранить")}},
        dismissButton={TextButton(onClick={editProfile=false}){Text("Отмена")}})
    AppPage(currentTab = "profile", onNavigate = onNavigate) {
        LazyColumn(
            contentPadding = PaddingValues(top = Dimens.toolbarTop, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(Dimens.regular),
        ) {
            item { Text("Ваш профиль", Modifier.padding(horizontal = 34.dp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground) }
            item {
                Row(Modifier.padding(horizontal = Dimens.regular).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(Dimens.md)) {
                    Box(Modifier.size(140.dp).background(MaterialTheme.colorScheme.surface, RoundedCornerShape(Dimens.cardRadius)),
                        contentAlignment = Alignment.BottomEnd) {
                        profile?.avatarPath?.let { path ->
                            RemoteImage(db.publicImageUrl("avatars",path),Modifier.fillMaxSize(),"Аватар")
                        }
                        // TODO: Заменить на кастомную SVG
                        Icon(Icons.Default.Settings, contentDescription = "Настроить аватар",
                            modifier = Modifier.padding(Dimens.sm).size(26.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(Dimens.inputRadius)).clickable { pickAvatar.launch("image/*") },
                            tint = MaterialTheme.colorScheme.onPrimary)
                    }
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("— ", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground)
                            // TODO: Заменить на кастомную SVG
                            Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.tertiary)
                            Text(" ${ownWorkReviews.size + companyReviewCount} отзывов", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground)
                        }
                        Text(profile?.fullName?.ifBlank { "Профиль пользователя" } ?: "Профиль пользователя", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
                        Text(email ?: "Электронная почта не указана", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Column(Modifier.padding(horizontal=Dimens.regular)) {
                    if(error!=null) Text("Ошибка: $error",color=MaterialTheme.colorScheme.error)
                    LinkButton("Изменить имя и город",{editProfile=true})
                }
            }
            item {
                Row(Modifier.padding(horizontal = Dimens.regular), horizontalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
                    StatTile(if(ownWorkReviews.isEmpty()) "—" else "%.1f".format(ownWorkReviews.map { it.rating }.average()), "Рейтинг", Modifier.weight(1f))
                    StatTile("${ownWorkReviews.size}", "Отзывов о работе", Modifier.weight(1f))
                    StatTile("${ownedCompanies.size}", "Компаний", Modifier.weight(1f))
                }
            }
            if(ownedCompanies.isNotEmpty()) item {
                Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.xxs)) {
                    Text("Отзывы о моих компаниях: $companyReviewCount",style=MaterialTheme.typography.titleMedium)
                    Text("Откройте «Моя организация», чтобы прочитать отзывы о компании.",
                        style=MaterialTheme.typography.bodyMedium)
                }
            }
            item {
                Column(Modifier.padding(horizontal = Dimens.regular), verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
                    Text("Моя карьера", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
                    Spacer(Modifier.height(Dimens.sm))
                    ProfileMenuRow("Моё резюме", selected = true, onClick = onResume)
                }
            }
            item {
                Column(Modifier.padding(horizontal = Dimens.regular), verticalArrangement = Arrangement.spacedBy(Dimens.xxs)) {
                    Text("Настройки", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
                    Spacer(Modifier.height(Dimens.sm))
                    ProfileMenuRow("Тема приложения", onClick = { showThemeDialog = true })
                    ProfileMenuRow("Помощь и поддержка", onClick = { onNavigate("help") })
                    ProfileMenuRow("Моя организация", onClick = onOrganization)
                    ProfileMenuRow("Выйти из аккаунта", onClick = onLogout)
                }
            }
        }
    }
}
