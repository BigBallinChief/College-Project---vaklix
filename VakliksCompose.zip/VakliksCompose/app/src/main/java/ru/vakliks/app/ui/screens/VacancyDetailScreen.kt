package ru.vakliks.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.vakliks.app.data.Vacancy
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun VacancyDetailScreen(vacancyId:String,onNavigate:(String)->Unit,onCompany:(String)->Unit) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope=rememberCoroutineScope()
    var job by remember(vacancyId){mutableStateOf<Vacancy?>(null)}
    var starred by remember{mutableStateOf(false)}
    var applied by remember{mutableStateOf(false)}
    var error by remember{mutableStateOf<String?>(null)}
    var busy by remember{mutableStateOf(false)}
    var publisher by remember { mutableStateOf<SupabaseDatabase.Profile?>(null) }
    LaunchedEffect(vacancyId){try{
        job=db.vacancy(vacancyId)
        publisher=db.vacancyPublisher(vacancyId)?.let { db.publicProfile(it) }
        starred=vacancyId in runCatching{db.favorites()}.getOrDefault(emptySet())
        applied=vacancyId in runCatching{db.appliedIds()}.getOrDefault(emptySet())
    }catch(e:Exception){error=e.message}}
    AppPage(currentTab="jobs",onNavigate=onNavigate){
        LazyColumn(contentPadding=PaddingValues(top=Dimens.toolbarTop,bottom=115.dp),verticalArrangement=Arrangement.spacedBy(Dimens.md)){
            item {Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.sm)){
                Greeting()
                if(error!=null)Text("Ошибка: $error",color=MaterialTheme.colorScheme.error)
                if(job==null) Text("${if(error==null)"Загрузка вакансии..." else "Не удалось открыть вакансию"}",style=MaterialTheme.typography.bodyMedium)
            }}
            job?.let{v->
                if(v.images.isNotEmpty()) item { VacancyPhotoCarousel(v.images) }
                item{Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                    Text(v.company,Modifier.clickable{onCompany(v.organizationId)},style=MaterialTheme.typography.bodyMedium)
                    Text(v.salary,style=MaterialTheme.typography.headlineMedium)
                    Text(v.title,style=MaterialTheme.typography.bodyLarge)
                }}
                publisher?.let { person -> item {
                    Row(Modifier.fillMaxWidth().padding(horizontal=Dimens.regular)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(Dimens.sm))
                        .clickable { onNavigate("user/${person.id}") }.padding(Dimens.sm),
                        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(Dimens.sm)) {
                        if(!person.avatarPath.isNullOrBlank()) {
                            RemoteImage(db.publicImageUrl("avatars",person.avatarPath),
                                Modifier.size(46.dp).clip(CircleShape),"Аватар автора")
                        } else {
                            Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.surfaceVariant,CircleShape),
                                contentAlignment=Alignment.Center) {Text(person.fullName.take(1).uppercase())}
                        }
                        Column(Modifier.weight(1f)) {
                            Text(person.fullName,style=MaterialTheme.typography.titleMedium)
                            Text("Профиль работодателя · посмотреть отзывы",style=MaterialTheme.typography.bodySmall,
                                color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }}
                item{Row(Modifier.padding(horizontal=Dimens.regular),horizontalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                    Box(Modifier.weight(1f)){PrimaryButton(if(applied)"Отклик отправлен" else if(busy)"Отправляем..." else "Откликнуться",{
                        if(!applied&&!busy)scope.launch{busy=true;try{db.apply(v.id);applied=true}catch(e:Exception){error=e.message}finally{busy=false}}
                    },Modifier.fillMaxWidth(),compact=true)}
                    Box(Modifier.size(Dimens.chipHeight).background(MaterialTheme.colorScheme.surfaceVariant,RoundedCornerShape(Dimens.inputRadius))
                        .clickable{scope.launch{try{db.setFavorite(v.id,!starred);starred=!starred}catch(e:Exception){error=e.message}}},contentAlignment=Alignment.Center){
                        // TODO: Заменить на кастомную SVG
                        Icon(if(starred)Icons.Default.Star else Icons.Default.StarBorder,contentDescription="Избранное")
                    }
                }}
                if(applied)item{
                    LinkButton("Перейти в сообщения",{onNavigate("messages")},Modifier.padding(horizontal=Dimens.regular))
                }
                item{Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                    Text("Описание вакансии",style=MaterialTheme.typography.titleLarge)
                    Text(v.summary.ifBlank{"Описание не указано"},style=MaterialTheme.typography.bodyLarge)
                }}
                item{Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.sm)){
                    Text("Условия работы",style=MaterialTheme.typography.titleLarge)
                    listOf("Город" to v.city,"График работы" to v.workSchedule,"Опыт" to v.experience,
                        "Формат работы" to v.workFormat,"Занятость" to v.employmentType,"Дата публикации" to v.publishedAt.take(10))
                        .filter{it.second.isNotBlank()}.forEach{(label,value)->Row(Modifier.fillMaxWidth()){
                            Text(label,Modifier.weight(1f),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(value,style=MaterialTheme.typography.bodyMedium)
                        }}
                }}

            }
        }
    }
}


@Composable
private fun VacancyPhotoCarousel(images:List<String>) {
    val pager=rememberPagerState(pageCount={images.size})
    Column(Modifier.fillMaxWidth().padding(horizontal=Dimens.regular),
        verticalArrangement=Arrangement.spacedBy(Dimens.xxs)) {
        HorizontalPager(state=pager, modifier=Modifier.fillMaxWidth().height(240.dp),
            pageSpacing=8.dp) { page ->
            RemoteImage(images[page],Modifier.fillMaxSize().clip(RoundedCornerShape(Dimens.sm)),"Фото вакансии ${page+1}")
        }
        if(images.size>1) Text("${pager.currentPage+1} / ${images.size}  ·  Листайте фотографии влево и вправо",
            style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
