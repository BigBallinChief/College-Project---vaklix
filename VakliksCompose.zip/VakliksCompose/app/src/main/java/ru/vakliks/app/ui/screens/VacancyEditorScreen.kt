package ru.vakliks.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.clip
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.launch
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

/** Editable vacancy form, with real creation/editing and Supabase Storage uploads. */
@Composable
fun VacancyEditorScreen(organizationId:String?, vacancyId:String?, onDone:()->Unit, onFavorites:()->Unit) {
    val context=LocalContext.current
    val db=remember(context){SupabaseDatabase(context)}
    val scope=rememberCoroutineScope()
    var title by remember{mutableStateOf("")}
    var description by remember{mutableStateOf("")}
    var city by remember{mutableStateOf("")}
    var salaryFrom by remember{mutableStateOf("")}
    var salaryTo by remember{mutableStateOf("")}
    var salaryPeriod by remember{mutableStateOf("month")}
    var schedule by remember{mutableStateOf("5/2")}
    var hours by remember{mutableStateOf("")}
    var night by remember{mutableStateOf(false)}
    var experience by remember{mutableStateOf("")}
    var workFormat by remember{mutableStateOf("")}
    var frequency by remember{mutableStateOf("")}
    var employment by remember{mutableStateOf("")}
    var specialization by remember{mutableStateOf("")}
    var images by remember{mutableStateOf<List<Uri>>(emptyList())}
    var existingPhotos by remember{mutableStateOf<List<SupabaseDatabase.StoredPhoto>>(emptyList())}
    var removedPhotos by remember{mutableStateOf<List<SupabaseDatabase.StoredPhoto>>(emptyList())}
    var busy by remember{mutableStateOf(false)}
    var confirmDeletion by remember { mutableStateOf(false) }
    var error by remember{mutableStateOf<String?>(null)}
    var ownerOrg by remember{mutableStateOf(organizationId)}
    val imagePicker=rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()){uris->
        images=(images+uris).distinct().take((5-existingPhotos.size).coerceAtLeast(0))
    }
    LaunchedEffect(vacancyId){if(vacancyId!=null)try{
        val v=db.vacancy(vacancyId)?:throw IllegalStateException("Вакансия не найдена")
        ownerOrg=v.organizationId
        title=v.title;description=v.summary;city=v.city
        salaryFrom=v.salaryFrom?.toString().orEmpty();salaryTo=v.salaryTo?.toString().orEmpty()
        salaryPeriod=v.salaryPeriod;schedule=v.workSchedule;hours=v.hoursPerDay?.toString().orEmpty()
        night=v.nightShifts;experience=v.experience;workFormat=v.workFormat
        frequency=v.paymentFrequency;employment=v.employmentType;specialization=v.specialization
        existingPhotos=db.vacancyPhotos(vacancyId)
    }catch(e:Exception){error=e.message}}
    fun submit(delete:Boolean=false){if(busy)return
        if(!delete&&(title.isBlank()||city.isBlank())){error="Заполните название и город";return}
        scope.launch{busy=true;error=null;try{
            if(delete){require(vacancyId!=null);db.deleteVacancyWithImages(vacancyId)}
            else {
                val draft=SupabaseDatabase.VacancyDraft(title,description,city,salaryFrom.toLongOrNull(),salaryTo.toLongOrNull(),
                    salaryPeriod,schedule,hours.toIntOrNull(),night,experience,workFormat,frequency,employment,specialization)
                val id=if(vacancyId==null){
                    val org=ownerOrg?:throw IllegalStateException("Сначала создайте организацию")
                    db.createVacancy(org,draft)
                }else {db.editVacancy(vacancyId,draft);vacancyId}
                removedPhotos.forEach { db.removeVacancyPhoto(id,it) }
                val free=(0..4).filter { index -> existingPhotos.none { it.order==index } }
                images.take(free.size).forEachIndexed { index,uri ->
                    val path=db.uploadPhoto(context,uri,"vacancy-images",id)
                    db.addVacancyImage(id,path,free[index])
                }
            }
            onDone()
        }catch(e:Exception){error=e.message}finally{busy=false}}
    }
    @Composable fun field(label:String,value:String,onChange:(String)->Unit,placeholder:String=label){
        Column(verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
            Text(label,style=MaterialTheme.typography.titleSmall)
            AppTextField(value,onChange,placeholder)
        }
    }
    @Composable fun chips(label:String, choices:List<Pair<String,String>>, current:String,onChoose:(String)->Unit){
        Column(verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
            Text(label,style=MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                choices.forEach{(text,value)->FilterChip(text,selected=current==value,onClick={onChoose(value)})}
            }
        }
    }
    if (confirmDeletion) {
        AlertDialog(
            onDismissRequest = { if (!busy) confirmDeletion = false },
            title = { Text("Удалить вакансию?") },
            text = { Text("Объявление будет удалено из каталога. Связанные фотографии и отклики также могут быть удалены. Отменить действие нельзя.") },
            confirmButton = {
                TextButton(enabled = !busy, onClick = { confirmDeletion = false; submit(delete = true) }) {
                    Text("Удалить", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDeletion = false }) { Text("Отмена") } }
        )
    }
    AppPage{
        LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(start=Dimens.regular,end=Dimens.regular,top=Dimens.toolbarTop,bottom=170.dp),verticalArrangement=Arrangement.spacedBy(Dimens.md)){
            item{Text(if(vacancyId==null)"Добавление вакансии" else "Редактирование вакансии",style=MaterialTheme.typography.titleLarge)}
            item{Column(verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                Text("Фотографии вакансии (до 5)",style=MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement=Arrangement.spacedBy(Dimens.xxs)){
                    val freeSlots=(0..4).filter { pos -> existingPhotos.none { it.order==pos } }
                    repeat(5){i->
                        val original=existingPhotos.firstOrNull { it.order==i }
                        val selectedPosition=freeSlots.indexOf(i)
                        val picked=if(selectedPosition>=0)images.getOrNull(selectedPosition) else null
                        Box(Modifier.weight(1f).height(80.dp)
                            .clip(RoundedCornerShape(Dimens.sm))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable {
                                when {
                                    original!=null -> {
                                        existingPhotos=existingPhotos-original
                                        removedPhotos=removedPhotos+original
                                        images=images.take(5-existingPhotos.size)
                                    }
                                    picked!=null -> images=images.filterIndexed{index,_ -> index!=selectedPosition}
                                    existingPhotos.size+images.size<5 -> imagePicker.launch("image/*")
                                }
                            }, contentAlignment=Alignment.Center){
                            when {
                                original!=null -> {
                                    RemoteImage(db.publicImageUrl("vacancy-images",original.path),Modifier.fillMaxSize(),"Фото вакансии")
                                    Icon(Icons.Default.Close,contentDescription="Убрать фотографию",
                                        modifier=Modifier.align(Alignment.TopEnd).size(20.dp),
                                        tint=MaterialTheme.colorScheme.error)
                                }
                                picked!=null -> AsyncImage(model=picked,contentDescription="Выбранное фото",
                                    modifier=Modifier.fillMaxSize().clip(RoundedCornerShape(Dimens.sm)),contentScale=ContentScale.Crop)
                                else -> {
                                    // TODO: Заменить на кастомную SVG
                                    Icon(Icons.Default.AddPhotoAlternate,contentDescription="Добавить фото",modifier=Modifier.size(27.dp))
                                }
                            }
                        }
                    }
                }
                Text("Нажмите на фото, чтобы убрать или заменить его. Изменения применятся после сохранения.",
                    style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Выбрано: ${images.size}, уже загружено: ${existingPhotos.size}",style=MaterialTheme.typography.bodySmall)
            }}
            item{field("Название",title,{title=it})}
            item{field("Регион / город",city,{city=it})}
            item{field("Описание вакансии",description,{description=it},"Обязанности и условия работы")}
            item{field("Зарплата от, ₽",salaryFrom,{salaryFrom=it.filter(Char::isDigit)})}
            item{field("Зарплата до, ₽",salaryTo,{salaryTo=it.filter(Char::isDigit)})}
            item{chips("Период оплаты",listOf("За месяц" to "month","За смену" to "shift","За час" to "hour","За услугу" to "service"),salaryPeriod,{salaryPeriod=it})}
            item{chips("График",listOf("5/2" to "5/2","2/2" to "2/2","6/1" to "6/1","3/3" to "3/3"),schedule,{schedule=it})}
            item{field("Часы в день",hours,{hours=it.filter(Char::isDigit)})}
            item{Row(verticalAlignment=Alignment.CenterVertically){Checkbox(night,{night=it});Text("Ночные смены")}}
            item{chips("Опыт",listOf("Без опыта" to "Нет опыта","1–3 года" to "1–3 года","3–6 лет" to "3–6 лет","6+ лет" to "6+ лет"),experience,{experience=it})}
            item{chips("Формат работы",listOf("На месте" to "На месте работодателя","Удалённо" to "Удалённо","Гибрид" to "Гибрид"),workFormat,{workFormat=it})}
            item{chips("Частота выплат",listOf("Ежедневно" to "Ежедневно","Еженедельно" to "Раз в неделю","Ежемесячно" to "Раз в месяц"),frequency,{frequency=it})}
            item{chips("Занятость",listOf("Полная" to "Полная занятость","Частичная" to "Частичная занятость","Подработка" to "Подработка"),employment,{employment=it})}
            item{field("Специализация",specialization,{specialization=it})}
            if(error!=null)item{Text("Ошибка: $error",color=MaterialTheme.colorScheme.error)}
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().background(MaterialTheme.colorScheme.background)
            .padding(horizontal=Dimens.regular,vertical=Dimens.sm),verticalArrangement=Arrangement.spacedBy(Dimens.xxs)){
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            PrimaryButton(if(busy)"Сохраняем..." else if(vacancyId==null)"Создать вакансию" else "Сохранить изменения",
                {submit()},Modifier.fillMaxWidth(),enabled=!busy,compact=true)
            if(vacancyId!=null)LinkButton("Удалить вакансию",{confirmDeletion=true})
        }
    }
}
