package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ru.vakliks.app.data.Vacancy
import ru.vakliks.app.data.VacancyFilters
import ru.vakliks.app.data.remote.SupabaseDatabase
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun VacancyListScreen(onNavigate:(String)->Unit,onOpen:(String)->Unit,onCompany:(String)->Unit,onNoResults:()->Unit, filters:VacancyFilters=VacancyFilters()) {
    val context = LocalContext.current
    val db = remember(context) { SupabaseDatabase(context) }
    val scope=rememberCoroutineScope()
    var jobs by remember { mutableStateOf<List<Vacancy>>(emptyList()) }
    var starred by remember { mutableStateOf<Set<String>>(emptySet()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember(filters) { mutableStateOf(filters.query) }
    var chip by remember { mutableStateOf("Краснодар") }
    LaunchedEffect(Unit) { try {jobs=db.vacancies();starred=runCatching{db.favorites()}.getOrDefault(emptySet())}
        catch(e:Exception){error=e.message}finally{loading=false} }
    val filtered=remember(jobs,query,filters){jobs.filter{filters.copy(query=query).matches(it)}}
    fun toggle(id:String) {scope.launch{try{db.setFavorite(id,id !in starred);starred=if(id in starred)starred-id else starred+id}catch(e:Exception){error=e.message}}}
    AppPage(currentTab="jobs",onNavigate=onNavigate) {
        LazyColumn(contentPadding=PaddingValues(top=Dimens.toolbarTop,bottom=108.dp),verticalArrangement=Arrangement.spacedBy(Dimens.xs)) {
            item {Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.sm)) {
                Greeting()
                SearchHeader(query,{query=it},onFavorites={onNavigate("favorites")},onFilters={onNavigate("filters")})
                QuickSearchChips(onSelect={chip=it;if(it!="Краснодар")onNavigate("filters")},selected=chip)
            }}
            item {Spacer(Modifier.height(22.dp))}
            item {Column(Modifier.padding(horizontal=Dimens.regular),verticalArrangement=Arrangement.spacedBy(Dimens.xs)) {
                Text(if(loading)"Загрузка вакансий..." else "Найдено ${filtered.size} вакансий",style=MaterialTheme.typography.titleSmall)
                SortingRow()
                if(error!=null)Text("Ошибка: $error",color=MaterialTheme.colorScheme.error)
                else if(!loading&&filtered.isEmpty())Text("Вакансий пока нет",style=MaterialTheme.typography.bodyMedium)
            }}
            items(filtered,key={it.id}) {v->VacancyCard(v,modifier=Modifier.padding(horizontal=Dimens.regular).fillMaxWidth().heightIn(min=175.dp),
                isFavorite=v.id in starred,onOpen={onOpen(v.id)},onFavorite={toggle(v.id)},onApply={onOpen(v.id)},onCompany={onCompany(v.organizationId)})}
        }
    }
}
