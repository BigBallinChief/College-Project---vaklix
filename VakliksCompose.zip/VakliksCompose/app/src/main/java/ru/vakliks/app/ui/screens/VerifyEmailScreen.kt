package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import ru.vakliks.app.R
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun VerifyEmailScreen(email: String, onOpenMail: () -> Unit, onResend: () -> Unit, onLogin: () -> Unit) {
    AppPage {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(bottom = Dimens.xl)) {
            Box(Modifier.fillMaxWidth().height(630.dp)) {
                MascotWatermark(Modifier.size(440.dp).offset(x = (-125).dp, y = (-135).dp))
                MascotArtwork(R.drawable.mascot_mail, Modifier.fillMaxSize().padding(horizontal = Dimens.regular), fadeBottom = true)
            }
            Column(Modifier.padding(horizontal = Dimens.regular)) {
                Text("Проверьте почту", style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.onBackground)
                Text(buildAnnotatedString {
                    append("Мы отправили ссылку для подтверждения на\n")
                    withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary)) { append(email) }
                    append("\nПерейдите по ней, чтобы продолжить.")
                }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.height(32.dp))
                PrimaryButton("Открыть почту", onOpenMail, Modifier.fillMaxWidth())
                Spacer(Modifier.height(Dimens.sm))
                Box(Modifier.fillMaxWidth(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    LinkButton("Отправить повторно", onResend)
                }
                Spacer(Modifier.height(Dimens.sm))
                Box(Modifier.fillMaxWidth(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    LinkButton("Уже подтвердили? Войти", onLogin)
                }
            }
        }
    }
}
