package ru.vakliks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import ru.vakliks.app.R
import ru.vakliks.app.ui.components.*
import ru.vakliks.app.ui.theme.Dimens

@Composable
fun WelcomeScreen(onRegister: () -> Unit, onLogin: () -> Unit) {
    AppPage {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(bottom = Dimens.lg)) {
            Box(Modifier.fillMaxWidth().height(640.dp)) {
                MascotWatermark(Modifier.size(440.dp).offset(x = (-125).dp, y = (-115).dp))
                MascotArtwork(R.drawable.mascot_welcome, Modifier.fillMaxSize().padding(horizontal = 28.dp), fadeBottom = true)
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = Dimens.regular)) {
                Text(
                    buildAnnotatedString {
                        append("Добро пожаловать\nв ")
                        withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary)) { append("Вакликс!") }
                    },
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Spacer(Modifier.height(Dimens.sm))
                Text("Находи работу мечты, откликайся на вакансии и открывай новые карьерные возможности",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.height(28.dp))
                PrimaryButton("Создать аккаунт", onRegister, Modifier.fillMaxWidth())
                Spacer(Modifier.height(Dimens.sm))
                Box(Modifier.fillMaxWidth(), contentAlignment = androidx.compose.ui.Alignment.Center) { LinkButton("Войти", onLogin) }
            }
        }
    }
}
