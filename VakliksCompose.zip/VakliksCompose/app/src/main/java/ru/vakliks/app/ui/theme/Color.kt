package ru.vakliks.app.ui.theme

import androidx.compose.ui.graphics.Color

// Цвета сняты непосредственно с PNG-макетов (основа фона: #EAEBED).
internal val Mint = Color(0xFF28CB9D)
internal val MintLight = Color(0xFF2ED6A7)
internal val Canvas = Color(0xFFEAEBED)
internal val CardWhite = Color(0xFFFCFCFD)
internal val FieldGray = Color(0xFFDEDFE3)
internal val MainInk = Color(0xFF12151C)
internal val MutedInk = Color(0xFF59647C)
internal val PlaceholderInk = Color(0xFFB9BDC5)
internal val ErrorPink = Color(0xFFEB6A76)
internal val ErrorBg = Color(0xFFF0DEDF)
internal val ActiveTint = Color(0xFFD8E9E7)
