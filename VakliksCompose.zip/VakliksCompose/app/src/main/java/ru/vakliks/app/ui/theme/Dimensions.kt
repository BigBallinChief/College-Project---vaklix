package ru.vakliks.app.ui.theme

import androidx.compose.ui.unit.dp

/** Размеры, общие для всех экранов, исходная сетка Figma: 440px по ширине. */
object Dimens {
    val none = 0.dp
    val xxs = 4.dp
    val xs = 6.dp
    val sm = 8.dp
    val md = 12.dp
    val regular = 16.dp
    val lg = 20.dp
    val xl = 24.dp
    val xxl = 32.dp
    val horizontal = 16.dp
    val cardRadius = 20.dp
    val inputRadius = 32.dp
    val buttonHeight = 56.dp
    val inputHeight = 48.dp
    val chipHeight = 40.dp
    val toolbarTop = 38.dp
    val navHeight = 58.dp
    val footerClearance = 88.dp
}
