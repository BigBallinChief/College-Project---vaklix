package ru.vakliks.app.ui.theme

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

/** Stored on device: theme setting is independent of Supabase account/session. */
object ThemePreference {
    var mode by mutableStateOf("system")
        private set

    fun initialize(context: Context) {
        mode = context.applicationContext.getSharedPreferences("vakclix_ui_settings", Context.MODE_PRIVATE)
            .getString("theme_mode", "system") ?: "system"
    }

    fun set(context: Context, choice: String) {
        require(choice in setOf("system", "light", "dark"))
        mode = choice
        context.applicationContext.getSharedPreferences("vakclix_ui_settings", Context.MODE_PRIVATE)
            .edit().putString("theme_mode", choice).apply()
    }
}

private val LightPalette = lightColorScheme(
    primary=Mint, onPrimary=Color.White, primaryContainer=ActiveTint,
    onPrimaryContainer=MainInk, secondary=MintLight, onSecondary=Color.White,
    background=Canvas,onBackground=MainInk,surface=CardWhite,onSurface=MainInk,
    surfaceVariant=FieldGray,onSurfaceVariant=MutedInk,outline=PlaceholderInk,
    outlineVariant=FieldGray,error=ErrorPink,onError=Color.White,
    errorContainer=ErrorBg,onErrorContainer=ErrorPink,
    inverseSurface=MutedInk,inverseOnSurface=CardWhite,tertiary=Mint,onTertiary=Color.White,
)

private val DarkPalette = darkColorScheme(
    primary=Color(0xFF49E1B4),onPrimary=Color(0xFF00382C),
    primaryContainer=Color(0xFF244B44),onPrimaryContainer=Color(0xFFB8FBE4),
    secondary=Color(0xFF6DDCBA),onSecondary=Color(0xFF00382C),
    background=Color(0xFF12171B),onBackground=Color(0xFFF1F3F5),
    surface=Color(0xFF242B30),onSurface=Color(0xFFF1F3F5),
    surfaceVariant=Color(0xFF343D43),onSurfaceVariant=Color(0xFFC1CDD1),
    outline=Color(0xFF92A0A6),outlineVariant=Color(0xFF465157),
    error=Color(0xFFFF8F9B),onError=Color(0xFF4D0713),
    errorContainer=Color(0xFF622C37),onErrorContainer=Color(0xFFFFD7DC),
    inverseSurface=Color(0xFFE2E8EA),inverseOnSurface=Color(0xFF222A30),
    tertiary=Color(0xFF6DDCBA),onTertiary=Color(0xFF00382C)
)

/** All default Compose Text styles inherit the correct foreground for the active theme.
 * This also fixes Text rendered directly inside custom Box/Column backgrounds, where
 * Material3 Surface does not automatically supply an onSurface content color.
 * Explicit labels on tinted buttons continue to use onPrimary / onPrimaryContainer.
 */
private fun themedTypography(textColor: Color): Typography = Typography(
    displayLarge = VakliksTypography.displayLarge.copy(color = textColor),
    displayMedium = VakliksTypography.displayMedium.copy(color = textColor),
    displaySmall = VakliksTypography.displaySmall.copy(color = textColor),
    headlineLarge = VakliksTypography.headlineLarge.copy(color = textColor),
    headlineMedium = VakliksTypography.headlineMedium.copy(color = textColor),
    headlineSmall = VakliksTypography.headlineSmall.copy(color = textColor),
    titleLarge = VakliksTypography.titleLarge.copy(color = textColor),
    titleMedium = VakliksTypography.titleMedium.copy(color = textColor),
    titleSmall = VakliksTypography.titleSmall.copy(color = textColor),
    bodyLarge = VakliksTypography.bodyLarge.copy(color = textColor),
    bodyMedium = VakliksTypography.bodyMedium.copy(color = textColor),
    bodySmall = VakliksTypography.bodySmall.copy(color = textColor),
    labelLarge = VakliksTypography.labelLarge.copy(color = textColor),
    labelMedium = VakliksTypography.labelMedium.copy(color = textColor),
    labelSmall = VakliksTypography.labelSmall.copy(color = textColor)
)

@Composable
fun VakliksTheme(content: @Composable () -> Unit) {
    val dark = when (ThemePreference.mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val palette = if (dark) DarkPalette else LightPalette
    MaterialTheme(
        colorScheme = palette,
        typography = themedTypography(palette.onBackground),
    ) {
        CompositionLocalProvider(LocalContentColor provides palette.onBackground) {
            content()
        }
    }
}
