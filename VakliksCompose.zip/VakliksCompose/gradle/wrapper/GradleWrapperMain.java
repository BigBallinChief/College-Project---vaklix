package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.CodeSource;
import java.util.*;
import java.util.zip.*;

/** Minimal independent bootstrap used only to download a fixed Gradle distribution. */
public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        CodeSource codeSource = GradleWrapperMain.class.getProtectionDomain().getCodeSource();
        File jar = new File(codeSource.getLocation().toURI());
        File propsFile = new File(jar.getParentFile(), "gradle-wrapper.properties");
        Properties props = new Properties();
        try (InputStream is = new FileInputStream(propsFile)) { props.load(is); }
        String distribution = props.getProperty("distributionUrl");
        if (distribution == null || !distribution.startsWith("https://services.gradle.org/distributions/gradle-")) {
            throw new IOException("Unexpected Gradle distribution URL in gradle-wrapper.properties");
        }
        String zipName = distribution.substring(distribution.lastIndexOf('/') + 1);
        String version = zipName.replace("-bin.zip", "");
        File cache = new File(System.getProperty("user.home"), ".gradle/wrapper/dists/" + version + "/vakliks");
        File ready = new File(cache, ".ready");
        if (!ready.exists()) {
            if (!cache.isDirectory() && !cache.mkdirs()) throw new IOException("Could not create " + cache);
            Path tmp = new File(cache, zipName + ".download").toPath();
            System.out.println("Downloading " + distribution);
            URLConnection connection = new URL(distribution).openConnection();
            connection.setConnectTimeout(30000);
            connection.setReadTimeout(120000);
            try (InputStream is = connection.getInputStream()) { Files.copy(is, tmp, StandardCopyOption.REPLACE_EXISTING); }
            Path root = cache.getCanonicalFile().toPath();
            try (ZipFile zip = new ZipFile(tmp.toFile())) {
                Enumeration<? extends ZipEntry> entries = zip.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry entry = entries.nextElement();
                    Path target = root.resolve(entry.getName()).normalize();
                    if (!target.startsWith(root)) throw new IOException("Unsafe entry: " + entry.getName());
                    if (entry.isDirectory()) { Files.createDirectories(target); continue; }
                    Files.createDirectories(target.getParent());
                    try (InputStream is = zip.getInputStream(entry)) { Files.copy(is, target, StandardCopyOption.REPLACE_EXISTING); }
                }
            }
            Files.deleteIfExists(tmp);
            if (!ready.createNewFile()) throw new IOException("Could not mark Gradle installation complete");
        }
        String gradleDir = zipName.replace("-bin.zip", "");
        boolean windows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        File executable = new File(cache, gradleDir + "/bin/gradle" + (windows ? ".bat" : ""));
        if (!executable.isFile()) throw new IOException("Gradle executable not found: " + executable);
        if (!windows) executable.setExecutable(true);
        List<String> command = new ArrayList<>();
        if (windows) { command.add("cmd.exe"); command.add("/c"); }
        command.add(executable.getAbsolutePath());
        command.addAll(Arrays.asList(args));
        File projectDir = jar.getParentFile().getParentFile().getParentFile();
        Process proc = new ProcessBuilder(command).directory(projectDir).inheritIO().start();
        System.exit(proc.waitFor());
    }
}
